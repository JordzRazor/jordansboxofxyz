# sniper — install

Write code in a browser chat, click a button, and it lands in the right file on
your disk. Then a local agent places it, and a second one repairs what the
patches broke.

## What you need first

| | why |
|---|---|
| **Python 3.9+** on PATH | the relay, the queue and the checks are Python, stdlib only — no pip install |
| **Chrome + [Tampermonkey](https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo)** | the capture half runs as a userscript in the page you are already logged into |
| **Claude Code CLI** *(optional)* | only needed for the Placer and Gardener. Everything else works without it |

Nothing is installed for you. The installer checks, tells you what is missing,
and sets up the rest.

## Install

```
powershell -ExecutionPolicy Bypass -File install.ps1
```

It generates a key unique to this machine, points placement at where you
unzipped it, creates a first environment, bakes the key into the userscript,
starts the relay, and opens the install page in your browser.

Then, **three steps, all in the browser:**

1. Install **[Tampermonkey](https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo)**, if you have not.
2. On the tab the installer opened, click **Install**. The key is already in it.
3. *Chrome 138+ only, and only if the buttons never appear:* `chrome://extensions`
   → Tampermonkey → Details → enable **Allow User Scripts**. MV3 runs nothing
   without it, and says nothing about why.

Open <https://chat.deepseek.com> or <https://chat.qwen.ai> and press `Alt+R`.

Console at <http://127.0.0.1:7355/console>. Your project at
<http://127.0.0.1:7356/><your-env>/.

Installer options: `-NoAutostart`, `-EnvName racer`, `-Quiet`.

## Starting a project without leaving the chat

The environment is the target: it is what `+ new` creates, what
`⧉ load environment` selects, and where a captured page is written. Those are
one thing, and the chat tab you are typing in decides which one.

1. In the chat, click the **`⧉`** button (bottom-left) → **`+ new environment`**.
2. Name it. The folder, the URL and this conversation are bound to that name in
   one step, and its address is dropped into your composer.
3. Ask for a page. A whole HTML document goes **live at that address** instead
   of queueing — refresh the tab to see it.

The `⧉` button always reads the current target, so you can see where the next
block lands without opening anything. Switching chat tabs switches the target
back to whatever *that* conversation owns; a chat the relay has never seen
leaves it alone rather than hijacking it.

Once a chat has declared an environment, that declaration wins — a page arriving
from it is a new build of that project, not a second project named after its
`<title>`.

## The loop

| in the chat | |
|---|---|
| `Alt+R` | send the house rules — **do this first in a new chat** |
| `⇩ codebase` / `Alt+C` | send the full source so it stops guessing |
| `→ Claude` | one code block |
| `⌖` hub | all code blocks, or the whole message |
| `⇧ what landed` / `Alt+W` | send back what landed and *why* the rest did not |

| in the console | |
|---|---|
| **drops** | review and apply; `apply all` runs the Placer |
| **🌿 gardener** | repairs what patches broke; badges only when there is work |
| env dropdown | switch project; `+ new` creates one |

## Is it working?

```
python selftest.py     19 checks against a running relay
python jscheck.py sniper.user.js console.html
python gamecheck.py    health of the current environment
```

## Updating

```
powershell -ExecutionPolicy Bypass -File install.ps1
```

Re-running the installer over an existing folder is safe: it keeps your key,
`roots.json`, `envs.json`, `bindings.json` and everything under `envs/`,
`drops/` and `context/`. Only the code is replaced.

The userscript updates itself. The relay serves it at
`http://127.0.0.1:7355/sniper.user.js?key=<your key>`, and the installed copy
carries that address as its `@updateURL` — so Tampermonkey re-checks it on its
own schedule and offers the new version whenever the relay's copy has a higher
`@version`. To force it now: Tampermonkey dashboard → the script → **Check for
updates**.

## Where your things live

| | |
|---|---|
| `envs/<name>/` | your projects, served over real HTTP (three.js needs that) |
| `drops/` | captured code waiting to be placed |
| `context/` | explanations — read for intent, never placed as code |
| `backups/` | every overwrite, before it happened |
| `refused/` | captures the guard turned away, with the reason |
| `.sniper_key` | this install's shared secret. Not in the zip; generated here |

## If something is wrong

- **Buttons missing on a chat page** — press `Alt+D`. That sends a DOM census to
  the relay window, which prints which selectors matched. Add a `sites.json`
  entry for that host; no re-install needed.
- **"relay unreachable"** — the relay window is closed. `.\run.ps1`.
- **"not sent — looks mid-render"** — the chat's own rendering is broken for
  that block. It is kept in `refused/` with the reason. Ask for a
  ```` ```javascript ```` fence rather than ```` ```text ````.
- **A drop did not land** — it was probably rejected on purpose. `⇧ what landed`
  sends the exact reasons back to the chat.
