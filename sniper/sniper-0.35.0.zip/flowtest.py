"""flowtest.py - walk the whole journey, end to end, against a running relay.

    python flowtest.py

selftest.py proves the relay's edges are safe (auth, containment, bad input).
This proves the thing you actually do:

    a new chat says "+ new environment"  ->  it is created and bound to that chat
    the chat sends a whole page          ->  it goes live at that address
    you switch to another chat           ->  the target follows
    you switch back                      ->  it follows back
    a chat nobody has seen               ->  changes nothing

It creates one environment named `flowtest-tmp` and removes it again, along with
its binding. It does not touch any environment of yours.
"""

import json
import os
import shutil
import sys
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
BASE = "http://127.0.0.1:7355"
STATIC = "http://127.0.0.1:7356"
TMP = "flowtest-tmp"

# Two chat addresses that are certainly not real conversations of yours.
CHAT_A = "https://chat.qwen.ai/c/flowtest-aaaaaaaa-0000-0000-0000-000000000001"
CHAT_B = "https://chat.deepseek.com/a/chat/s/flowtest-bbbbbbbb-0000-0000-0000-000000000002"

PAGE = ("<!DOCTYPE html>\n<html>\n<head><title>Something Else Entirely</title></head>\n"
        "<body><script>window.__flowtest = 1;</script></body>\n</html>\n")

passed = failed = 0


def chat_key_of(url: str) -> str:
    """The relay's own key shape: host + the last path segment."""
    u = url.split("?")[0].split("#")[0]
    rest = u.split("://", 1)[-1]
    host, _, path = rest.partition("/")
    seg = [s for s in path.split("/") if s]
    return host + ":" + (seg[-1] if seg else "new")


def key() -> str:
    with open(os.path.join(ROOT, ".sniper_key"), encoding="ascii") as fh:
        return fh.read().strip()


KEY = key()


def call(path, payload=None, method=None, with_key=True):
    m = method or ("POST" if payload is not None else "GET")
    data = json.dumps(payload).encode() if payload is not None else None
    headers = {"Content-Type": "application/json"}
    if with_key:
        headers["X-Sniper-Key"] = KEY
    req = urllib.request.Request(BASE + path, data=data, method=m, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read().decode("utf-8", "replace")
            try:
                return r.status, json.loads(raw)
            except ValueError:
                return r.status, {"raw": raw}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(raw)
        except ValueError:
            return e.code, {"raw": raw}


def check(name, got, want):
    global passed, failed
    if got == want:
        passed += 1
        print("  [PASS] " + name)
    else:
        failed += 1
        print("  [FAIL] " + name)
        print("         want %r" % (want,))
        print("         got  %r" % (got,))


def cleanup(before_current):
    """Leave no trace: the environment, its binding, and the current target."""
    d = os.path.join(ROOT, "envs", TMP)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)

    ef = os.path.join(ROOT, "envs.json")
    try:
        with open(ef, encoding="utf-8") as fh:
            envs = json.load(fh)
        if envs.pop(TMP, None) is not None:
            with open(ef, "w", encoding="utf-8") as fh:
                json.dump(envs, fh, indent=2)
    except Exception:
        pass

    bf = os.path.join(ROOT, "bindings.json")
    try:
        with open(bf, encoding="utf-8") as fh:
            binds = json.load(fh)
        # By env AND by chat: step 4 deliberately binds CHAT_B to an
        # environment of yours, and leaving that behind would make the very
        # next run's "an unknown chat does not hijack" check pass for the
        # wrong reason - the chat would no longer be unknown.
        ours = {chat_key_of(CHAT_A), chat_key_of(CHAT_B)}
        drop = [k for k, v in binds.items()
                if (v or {}).get("env") == TMP or k in ours]
        for k in drop:
            binds.pop(k, None)
        if drop:
            with open(bf, "w", encoding="utf-8") as fh:
                json.dump(binds, fh, indent=2)
    except Exception:
        pass

    if before_current:
        call("/env", {"name": before_current})


def main():
    print("\nflowtest - the journey, not the edges")

    status, health = call("/health", with_key=False)
    if status != 200:
        print("  relay is not answering on %s - start it with .\\run.ps1" % BASE)
        return 1

    status, r = call("/env")
    before_current = r.get("current") or ""
    print("  current environment before this test: %r\n" % before_current)

    # If a previous run died mid-way, start clean.
    cleanup("")

    try:
        print("1. a new chat asks for an environment")
        status, r = call("/newenv", {"name": TMP, "label": "Flow Test",
                                     "url": CHAT_A, "switch": True})
        check("created", status, 200)
        check("bound to the chat that asked", r.get("bound"), True)
        check("became the current target", r.get("current"), TMP)
        url = r.get("url")
        check("address is on the static server", url, "%s/%s/" % (STATIC, TMP))

        print("\n2. that chat sends a whole page")
        status, r = call("/drop", {"text": PAGE, "site": "chat.qwen.ai",
                                   "kind": "codeblock", "url": CHAT_A,
                                   "title": "Something Else Entirely",
                                   "lang": "html"})
        check("accepted", status, 200)
        check("went live rather than queueing", r.get("routed"), "env")
        # The page calls itself "Something Else Entirely". The chat's
        # declaration has to win, or every new build starts a new project.
        check("landed in the DECLARED environment", r.get("env"), TMP)
        check("relay says the name came from the declaration", r.get("declared"), True)

        print("\n3. it is served, not staged")
        try:
            with urllib.request.urlopen(url, timeout=6) as resp:
                body = resp.read().decode("utf-8", "replace")
            check("served over http", resp.status, 200)
            check("it is the page that was sent", "window.__flowtest = 1" in body, True)
        except Exception as exc:
            check("served over http", "error: %s" % exc, 200)

        print("\n4. switching conversation moves the target")
        status, r = call("/bind", {"url": CHAT_B, "site": "chat.deepseek.com"})
        check("an unknown chat does not hijack", r.get("switched"), False)
        check("target left alone", r.get("current"), TMP)

        status, r = call("/bind", {"url": CHAT_B, "env": before_current or TMP})
        check("declaring one for that chat works", r.get("current"),
              before_current or TMP)

        status, r = call("/bind", {"url": CHAT_A, "site": "chat.qwen.ai"})
        check("coming back restores the first", r.get("current"), TMP)

        status, r = call("/bind", {"url": CHAT_A, "site": "chat.qwen.ai"})
        check("staying put does not churn", r.get("switched"), False)
    finally:
        print("\ncleanup")
        cleanup(before_current)
        status, r = call("/env")
        check("environment removed", TMP in [e.get("name") for e in r.get("envs", [])],
              False)
        check("current target restored", r.get("current"), before_current)

    print("\n" + "-" * 60)
    print("  %d passed, %d failed" % (passed, failed))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
