<#
  tray.ps1 - the sniper relay as a background process with a tray icon.

  Two jobs, which are really the same job:

    1. Keep the relay running without a console window in the way. That window
       WAS the log, so hiding it moves the log into runs\ and puts it one click
       away on the tray menu. Hiding the window is fine; losing the evidence
       never is - that lesson cost this project three separate debugging
       sessions.

    2. Never serve stale code. relay.py is the ONLY file that needs a restart
       to take effect: console.html, sites.json and roots.json are re-read on
       every request. So this watches relay.py's bytes and restarts the child
       the moment they change. That is the rot we hit twice by hand today -
       editing relay.py and then reading answers from a relay still running the
       old copy.

    .\tray.ps1              start the relay, sit in the tray, watch for updates
    .\tray.ps1 -NoWatch     same, but do not auto-restart on a code change
#>
param([switch]$NoWatch)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$runs = Join-Path $here 'runs'
if (-not (Test-Path $runs)) { New-Item -ItemType Directory -Path $runs | Out-Null }

$relayPy = Join-Path $here 'relay.py'
$consoleUrl = 'http://127.0.0.1:7355/console'

# Python, the same way run.ps1 finds it. -u because a buffered child that dies
# takes its last words with it.
$pyCmd = Get-Command py -ErrorAction SilentlyContinue
if ($pyCmd) { $script:exe = $pyCmd.Source; $script:pre = @('-3', '-u') }
else {
  $p3 = Get-Command python -ErrorAction SilentlyContinue
  if (-not $p3) {
    [void][System.Windows.Forms.MessageBox]::Show('No Python found on PATH.', 'sniper')
    exit 1
  }
  $script:exe = $p3.Source; $script:pre = @('-u')
}

$script:proc = $null
$script:log = $null
$script:sig = (Get-FileHash $relayPy -Algorithm SHA256).Hash
$script:restarts = 0

function Start-Relay {
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $script:log = Join-Path $runs ('relay-' + $stamp + '.log')
  $errLog     = Join-Path $runs ('relay-' + $stamp + '.err.log')
  $argList = $script:pre + @($relayPy)
  $script:proc = Start-Process -FilePath $script:exe -ArgumentList $argList `
      -WorkingDirectory $here -WindowStyle Hidden -PassThru `
      -RedirectStandardOutput $script:log -RedirectStandardError $errLog
  $script:sig = (Get-FileHash $relayPy -Algorithm SHA256).Hash
}

function Stop-Relay {
  if ($script:proc -and -not $script:proc.HasExited) {
    Stop-Process -Id $script:proc.Id -Force -ErrorAction SilentlyContinue
  }
}

function Say($title, $text) {
  $script:icon.BalloonTipTitle = $title
  $script:icon.BalloonTipText = $text
  $script:icon.ShowBalloonTip(4000)
}

# ---- the tray presence ----------------------------------------------------
$script:icon = New-Object System.Windows.Forms.NotifyIcon
try { $script:icon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($script:exe) }
catch { $script:icon.Icon = [System.Drawing.SystemIcons]::Application }
$script:icon.Text = 'sniper relay - 127.0.0.1:7355'
$script:icon.Visible = $true

$script:ctx = New-Object System.Windows.Forms.ApplicationContext
$menu = New-Object System.Windows.Forms.ContextMenuStrip

[void]$menu.Items.Add('Open console', $null, { Start-Process $consoleUrl })
[void]$menu.Items.Add('Show log', $null, {
  if ($script:log -and (Test-Path $script:log)) { Start-Process notepad.exe $script:log }
  else { Start-Process $runs }
})
[void]$menu.Items.Add('Open relay folder', $null, { Start-Process $here })
[void]$menu.Items.Add('-')
[void]$menu.Items.Add('Restart relay', $null, {
  Stop-Relay; Start-Sleep -Milliseconds 400; Start-Relay
  Say 'sniper' 'Relay restarted.'
})
[void]$menu.Items.Add('Stop relay and quit', $null, {
  Stop-Relay
  $script:icon.Visible = $false
  $script:ctx.ExitThread()
})
$script:icon.ContextMenuStrip = $menu
$script:icon.add_DoubleClick({ Start-Process $consoleUrl })

# ---- supervise ------------------------------------------------------------
# A crash must announce itself. A silent background process that died an hour
# ago is worse than no background process at all.
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2000
$timer.add_Tick({
  if ($script:proc -and $script:proc.HasExited) {
    Say 'sniper relay stopped' ('Exit code ' + $script:proc.ExitCode + '. Tray menu -> Show log.')
    $script:proc = $null
    return
  }
  if ($NoWatch) { return }
  try { $now = (Get-FileHash $relayPy -Algorithm SHA256).Hash } catch { return }
  if ($now -ne $script:sig) {
    $script:restarts++
    Stop-Relay; Start-Sleep -Milliseconds 400; Start-Relay
    Say 'sniper relay updated' 'relay.py changed on disk - restarted on the new code.'
  }
})
$timer.Start()

Start-Relay
Say 'sniper relay' 'Running in the background. Double-click for the console.'
[System.Windows.Forms.Application]::Run($script:ctx)
