<#
  run.ps1 - start the sniper relay.

  Leave this window open while you're sniping. Ctrl-C stops it.
#>

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) { $exe = $py.Source; $pre = @('-3') }
else {
  $p3 = Get-Command python -ErrorAction SilentlyContinue
  if (-not $p3) { Write-Host 'No Python found on PATH.' -ForegroundColor Red; exit 1 }
  $exe = $p3.Source; $pre = @()
}

$Host.UI.RawUI.WindowTitle = 'sniper relay - 127.0.0.1:7355'
& $exe @pre (Join-Path $here 'relay.py')
$code = $LASTEXITCODE

# Ctrl-C is a clean stop and returns 0, so the window closes the way you expect.
# Anything else is a crash - and a crash that closes its own window takes the
# traceback with it, which is the one failure this project keeps having to
# re-diagnose. Launched from a shortcut there is no parent console to read
# afterwards, so hold the window open and say so.
if ($code -ne 0) {
  Write-Host ''
  Write-Host "  relay exited with code $code - its traceback is above." -ForegroundColor Red
  Write-Host '  Press Enter to close this window.' -ForegroundColor DarkGray
  [void](Read-Host)
}
exit $code
