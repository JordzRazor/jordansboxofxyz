#!/usr/bin/env python3
"""
selftest - exercise a running sniper relay end to end.

    py -3 selftest.py            (relay must already be up on 127.0.0.1:7355)

Checks health, both auth rejections, addressed/unaddressed drops, the BOM
tolerance, the body ceiling, and - the one that matters - that a hostile
`target` is staged as inert text and never touches the filesystem as a path.
"""

import json
import os
import sys
import urllib.error
import urllib.request
import core

ROOT = os.path.dirname(os.path.abspath(__file__))
DROPS = os.path.join(ROOT, "drops")
URL = "http://127.0.0.1:7355"
KEY = open(os.path.join(ROOT, ".sniper_key"), encoding="ascii").read().strip()

BS = chr(92)                      # keep literal backslashes out of source escapes
TRAVERSAL = BS.join(["..", "..", "..", "Windows", "System32", "drivers", "etc", "hosts"])
WINPATH = BS.join(["mcmod", "pack", "data", "hello.mcfunction"])

_passed, _failed = 0, 0
_made = []          # drop ids this run created, so it can tidy up after itself


def check(name, got, want):
    global _passed, _failed
    ok = got == want
    _passed, _failed = _passed + ok, _failed + (not ok)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}"
          + ("" if ok else f"\n         got  {got!r}\n         want {want!r}"))


def post(payload, key=KEY, raw=None):
    body = raw if raw is not None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(URL + "/drop", data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    if key is not None:
        req.add_header("X-Sniper-Key", key)
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            status, body = r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    if body.get("id") and not body.get("duplicate"):
        _made.append(body["id"])
    return status, body


def cleanup():
    """Remove only what this run created. A regression run has no business
    leaving probes in a live queue - they read as real work later."""
    gone = 0
    for drop_id in _made:
        for stage in ("drops", "working"):
            for ext in (".json", ".txt"):
                p = os.path.join(ROOT, stage, drop_id + ext)
                if os.path.exists(p):
                    try:
                        os.remove(p)
                        gone += 1
                    except OSError:
                        pass
    return gone


def main():
    print("\nsniper selftest\n" + "-" * 60)

    with urllib.request.urlopen(URL + "/health", timeout=5) as r:
        health = json.loads(r.read().decode("utf-8"))
    check("health responds ok", health.get("ok"), True)
    before = set(os.listdir(DROPS)) if os.path.isdir(DROPS) else set()

    print("\nauth")
    check("no key -> 401", post({"text": "nope"}, key=None)[0], 401)
    check("wrong key -> 401", post({"text": "nope"}, key="not-the-key")[0], 401)

    print("\ndrops")
    status, r = post({
        "text": f"// >> {WINPATH} @replace  first smoke test\nsay hello\nsay world",
        "url": "https://chat.deepseek.com/a/chat/s/test", "title": "smoke",
        "site": "deepseek", "kind": "codeblock", "lang": "mcfunction"})
    check("addressed -> 200", status, 200)
    check("target parsed", r.get("target"), WINPATH)
    check("mode parsed", r.get("mode"), "replace")
    check("directive line stripped", r.get("lines"), 2)
    addressed_id = r.get("id")

    status, r = post({"text": "just some prose with no directive line",
                      "site": "deepseek", "kind": "selection"})
    check("unaddressed -> 200", status, 200)
    check("unaddressed target is null", r.get("target"), None)

    status, r = post(None, raw=b"\xef\xbb\xbf" + json.dumps(
        {"text": "bom-prefixed body", "site": "t", "kind": "selection"}).encode("utf-8"))
    check("BOM tolerated", status, 200)

    check("empty text -> 400", post({"text": "   "})[0], 400)
    check("garbage json -> 400", post(None, raw=b"{not json")[0], 400)
    check("oversize -> 413", post(None, raw=b"x" * (5 * 1024 * 1024))[0], 413)

    # The structure guard is shared with the userscript through core.py, so it
    # is tested where both sides can see it break.
    # The relay serves the userscript so installing (and updating) is one
    # click. It carries the key, so it must not be readable without one.
    print("\nuserscript install route")
    req = urllib.request.Request(URL + "/sniper.user.js")
    try:
        urllib.request.urlopen(req, timeout=8)
        check("no key -> refused", "served it anyway", 401)
    except urllib.error.HTTPError as e:
        check("no key -> 401", e.code, 401)
    req = urllib.request.Request(URL + "/sniper.user.js?key=" + KEY)
    with urllib.request.urlopen(req, timeout=8) as r:
        js = r.read().decode("utf-8", "replace")
        check("with key -> 200", r.status, 200)
        check("served as javascript",
              r.headers.get("Content-Type", "").startswith("text/javascript"), True)
    check("carries the update address", "@updateURL" in js, True)
    check("no placeholder left in it", "__SNIPER_KEY__" in js, False)

    print("\nstructure guard (core.py - shared with the userscript)")
    check("cut-off html doc is named",
          bool(core.corruption_in("<!DOCTYPE html>\n<html>\n<body>hi\n")), True)
    check("complete html doc passes",
          core.corruption_in("<!DOCTYPE html>\n<html><body>hi</body>\n</html>\n"), None)
    check("html fragment passes",
          core.corruption_in('<div class="x">\n  <p>hi</p>\n</div>'), None)
    check("repeated line caught",
          bool(core.corruption_in("const a = 1;\nconst a = 1;\n")), True)

    print("\ncontainment")
    status, r = post({"text": f"// >> {TRAVERSAL} @replace\nEVIL",
                      "site": "deepseek", "kind": "codeblock"})
    check("traversal target -> 200 (staged, not acted on)", status, 200)
    check("traversal kept verbatim as metadata", r.get("target"), TRAVERSAL)

    after = set(os.listdir(DROPS))
    new = after - before
    escaped = [f for f in new if ".." in f or "/" in f or BS in f]
    check("no new file escaped drops\\", escaped, [])
    check("hosts file untouched",
          os.path.exists(r"C:\Windows\System32\drivers\etc\hosts")
          and "EVIL" not in open(r"C:\Windows\System32\drivers\etc\hosts",
                                 encoding="utf-8", errors="replace").read(),
          True)

    if addressed_id:
        txt = os.path.join(DROPS, addressed_id + ".txt")
        check("sidecar written", os.path.exists(txt), True)
        if os.path.exists(txt):
            check("sidecar is placeable verbatim",
                  open(txt, encoding="utf-8").read(), "say hello\nsay world")

    removed = cleanup()
    print("-" * 60)
    print(f"  {_passed} passed, {_failed} failed"
          f"  (tidied {removed} test file(s) out of the queue)\n")
    return 1 if _failed else 0


if __name__ == "__main__":
    # A run that dies partway - an assertion, a closed pipe, Ctrl-C - must
    # still tidy. Probes left in a live queue read as real work later, and the
    # next run dedupes against them and quietly stops testing anything.
    try:
        sys.exit(main())
    finally:
        cleanup()
