<#
  install-autostart.ps1 - make the relay come up on its own at login.

    .\install-autostart.ps1              install both mechanisms
    .\install-autostart.ps1 -Uninstall   remove both

  Two mechanisms on purpose, because they fail differently:

    1. Startup-folder shortcut - fires at logon, MINIMIZED not hidden, so the
       relay window stays reachable in the taskbar. That window is the live log:
       the DOM census and every drop print there.
    2. Scheduled task, delayed 1 minute - the belt to the shortcut's braces, for
       when the Startup folder is skipped (fast-startup, a policy, a bad login).

  Safe to run both: the relay is single-instance. Whichever gets there first
  serves, and the other probes /health, finds it up, and exits quietly. Normally
  the shortcut wins, so you get the visible window.
#>

param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
$here     = Split-Path -Parent $MyInvocation.MyCommand.Path
$runps1   = Join-Path $here 'run.ps1'
$startup  = [Environment]::GetFolderPath('Startup')
$lnk      = Join-Path $startup 'Sniper Relay.lnk'
$taskName = 'SniperRelay'

if ($Uninstall) {
  if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "  removed $lnk" -ForegroundColor Yellow }
  else { Write-Host '  no startup shortcut to remove' -ForegroundColor DarkGray }
  $t = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($t) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false; Write-Host "  removed task '$taskName'" -ForegroundColor Yellow }
  else { Write-Host '  no scheduled task to remove' -ForegroundColor DarkGray }
  Write-Host ''
  Write-Host '  Autostart removed. run.ps1 is the manual switch again.' -ForegroundColor Cyan
  exit 0
}

if (-not (Test-Path $runps1)) { Write-Host "run.ps1 not found at $runps1" -ForegroundColor Red; exit 1 }

# ---- 1. Startup-folder shortcut (minimized: the window is the log) ----------
$sh = New-Object -ComObject WScript.Shell
$s  = $sh.CreateShortcut($lnk)
$s.TargetPath       = (Get-Command powershell).Source
$s.Arguments        = "-NoProfile -ExecutionPolicy Bypass -File `"$runps1`""
$s.WorkingDirectory = $here
$s.WindowStyle      = 7          # 7 = minimized
$s.Description      = 'Sniper relay - localhost sink for sniped text'
$s.Save()
Write-Host "  [1/2] startup shortcut -> $lnk" -ForegroundColor Green

# ---- 2. Scheduled task at logon, delayed so the shortcut normally wins ------
try {
  $existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($existing) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false }

  $action  = New-ScheduledTaskAction -Execute (Get-Command powershell).Source `
             -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File `"$runps1`"" `
             -WorkingDirectory $here
  $trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
  $trigger.Delay = 'PT1M'
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries `
              -DontStopIfGoingOnBatteries -StartWhenAvailable `
              -ExecutionTimeLimit ([TimeSpan]::Zero)

  Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
    -Settings $settings -Description 'Fallback starter for the sniper relay' | Out-Null
  Write-Host "  [2/2] scheduled task '$taskName' at logon +1min" -ForegroundColor Green
} catch {
  Write-Host "  [2/2] scheduled task FAILED: $($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host "        the startup shortcut alone still covers you." -ForegroundColor DarkGray
}

Write-Host ''
Write-Host '  Autostart installed. Undo with:  .\install-autostart.ps1 -Uninstall' -ForegroundColor Cyan
