<#
  install.ps1 - set up sniper on this machine.

      powershell -ExecutionPolicy Bypass -File install.ps1

  Does the things a fresh copy cannot ship with:
    - generates a key unique to THIS install
    - writes roots.json pointing at wherever you unzipped it
    - creates a first environment and serves it
    - bakes the key into the userscript so there is nothing to configure
    - optionally starts the relay at login

  It does NOT install Tampermonkey or Python - it checks for them and tells you
  what is missing, because silently installing software on someone's machine is
  not a thing an installer should do.

      -NoAutostart     skip the login shortcut + scheduled task
      -EnvName racer   name the first environment (default: myproject)
#>

param(
  [switch]$NoAutostart,
  [switch]$Quiet,               # take defaults, ask nothing
  [string]$EnvName = "myproject",
  [string]$CloudUrl = "",       # optional Azure inbox
  [string]$CloudKey = ""
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say($msg, $colour = 'Gray') { Write-Host "  $msg" -ForegroundColor $colour }
function Head($msg) { Write-Host ""; Write-Host $msg -ForegroundColor Cyan }

Head "sniper installer"
Say "installing into $here"

# ---- 1. prerequisites ------------------------------------------------------
Head "[1/6] checking what is already here"

$py = $null
foreach ($c in @('py', 'python', 'python3')) {
  $cmd = Get-Command $c -ErrorAction SilentlyContinue
  if ($cmd) { $py = $cmd.Source; break }
}
if (-not $py) {
  Say "Python not found on PATH." Red
  Say "Install it from https://python.org (3.9+), tick 'Add to PATH', then re-run." Yellow
  exit 1
}
$pyver = (& $py -c "import sys;print('%d.%d'%sys.version_info[:2])" 2>$null)
Say "python $pyver at $py" Green

$chrome = "$env:LOCALAPPDATA\Google\Chrome\User Data"
$tm = $null
if (Test-Path $chrome) {
  foreach ($prof in (Get-ChildItem $chrome -Directory -ErrorAction SilentlyContinue |
                     Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })) {
    $ext = Join-Path $prof.FullName 'Extensions\dhdgffkkebhmkfjojejmpbldmpobfkfo'
    if (Test-Path $ext) { $tm = $prof.Name; break }
  }
}
if ($tm) { Say "Tampermonkey found in Chrome profile '$tm'" Green }
else {
  Say "Tampermonkey NOT found." Yellow
  Say "Install it first: https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo" Yellow
  Say "Then re-run this installer - everything else will still be set up." Yellow
}

# ---- 2. a key for THIS install --------------------------------------------
Head "[2/6] generating a key for this install"
$keyfile = Join-Path $here '.sniper_key'
if (Test-Path $keyfile) {
  $key = (Get-Content $keyfile -Raw).Trim()
  Say "keeping the existing key (so an update does not break your userscript)"
} else {
  $bytes = New-Object byte[] 24
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $key = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
  [System.IO.File]::WriteAllText($keyfile, $key, (New-Object System.Text.UTF8Encoding($false)))
  Say "wrote .sniper_key" Green
}

# ---- 3. roots.json for THIS machine ---------------------------------------
Head "[3/6] where placement is allowed to write"
$rootsFile = Join-Path $here 'roots.json'
if (Test-Path $rootsFile) {
  Say "roots.json already exists - leaving it alone"
} else {
  $parent = Split-Path -Parent $here
  $roots = [ordered]@{
    sniper = ($here -replace '\\', '/')
    projects = ($parent -replace '\\', '/')
  }
  ($roots | ConvertTo-Json) | Out-File -FilePath $rootsFile -Encoding utf8
  Say "wrote roots.json - placement is confined to:" Green
  Say "    sniper   = $here"
  Say "    projects = $parent"
  Say "add more folders to roots.json if you want to place code elsewhere."
}

# ---- 4. a first environment ------------------------------------------------
Head "[4/6] first environment"
$envsFile = Join-Path $here 'envs.json'
if (Test-Path $envsFile) {
  Say "envs.json already exists - leaving it alone"
} else {
  $envs = [ordered]@{ $EnvName = [ordered]@{
    type = 'web'; label = $EnvName
    note = "snipe over envs/$EnvName/index.html with @replace"
  } }
  ($envs | ConvertTo-Json -Depth 4) | Out-File -FilePath $envsFile -Encoding utf8
  $envDir = Join-Path $here "envs\$EnvName"
  New-Item -ItemType Directory -Force -Path $envDir | Out-Null
  # Same starter the relay's /newenv writes - one file, so they cannot diverge.
  $starter = Join-Path $here 'starter.html'
  $index = Join-Path $envDir 'index.html'
  if ((Test-Path $starter) -and -not (Test-Path $index)) {
    $html = [System.IO.File]::ReadAllText($starter).Replace('__NAME__', $EnvName)
    [System.IO.File]::WriteAllText($index, $html, (New-Object System.Text.UTF8Encoding($false)))
    Say "created environment '$EnvName' with a starter page" Green
  } else {
    Say "created environment '$EnvName'" Green
  }
}
# point config.json at it
$cfgFile = Join-Path $here 'config.json'
if (Test-Path $cfgFile) {
  $cfg = Get-Content $cfgFile -Raw | ConvertFrom-Json
  if (-not $cfg.current_env) {
    $cfg | Add-Member -NotePropertyName current_env -NotePropertyValue $EnvName -Force
    ($cfg | ConvertTo-Json -Depth 6) | Out-File -FilePath $cfgFile -Encoding utf8
    Say "config.json current_env = $EnvName"
  }
}

# ---- 5. the userscript, with the key baked in ------------------------------
Head "[5/6] preparing the userscript"
$srcJs = Join-Path $here 'sniper.user.js'
if (-not (Test-Path $srcJs)) { Say "sniper.user.js missing" Red; exit 1 }
$js = [System.IO.File]::ReadAllText($srcJs)
if ($js -match "__SNIPER_KEY__") {
  $js = $js.Replace('__SNIPER_KEY__', $key)
  [System.IO.File]::WriteAllText($srcJs, $js, (New-Object System.Text.UTF8Encoding($false)))
  Say "baked this install's key into sniper.user.js" Green
} else {
  Say "userscript already carries a key - left as is"
}

# ---- 5b. the credentials only YOU can supply -------------------------------
Head "[5b/6] accounts"

Say "The chat itself needs no key here - you stay logged into DeepSeek or Qwen"
Say "in Chrome, and the userscript reads the page you are already looking at."
Write-Host ""

# Claude Code: needed only for the Placer and the Gardener.
$claude = Join-Path $env:USERPROFILE '.local\bin\claude.exe'
if (-not (Test-Path $claude)) {
  $c = Get-Command claude -ErrorAction SilentlyContinue
  if ($c) { $claude = $c.Source } else { $claude = $null }
}
if ($claude) {
  Say "Claude Code CLI found - the Placer and Gardener will work." Green
  Say "  (it uses your own Claude login; nothing is stored by sniper)"
} else {
  Say "Claude Code CLI not found." Yellow
  Say "  Everything except the Placer and the Gardener still works."
  Say "  Install it and sign in, then the buttons light up - no re-install needed." Yellow
}

# Optional: the Azure inbox, for driving this from another machine.
$cloudFile = Join-Path $here 'cloud.json'
if ($CloudUrl -and $CloudKey) {
  @{ url = $CloudUrl.TrimEnd('/'); key = $CloudKey } | ConvertTo-Json |
    Out-File -FilePath $cloudFile -Encoding utf8
  Say "wrote cloud.json for $CloudUrl" Green
} elseif (-not $Quiet -and -not (Test-Path $cloudFile)) {
  Write-Host ""
  Say "Optional: a cloud inbox (Azure) lets you snipe from any machine."
  Say "Leave blank to skip - you can add cloud.json later."
  $u = Read-Host "  cloud URL (https://<app>.azurewebsites.net)"
  if ($u) {
    $k = Read-Host "  cloud key (SNIPER_KEY set on that app)"
    if ($k) {
      @{ url = $u.TrimEnd('/'); key = $k } | ConvertTo-Json |
        Out-File -FilePath $cloudFile -Encoding utf8
      Say "wrote cloud.json - run the bridge with:  $py worker.py" Green
    }
  } else {
    Say "skipped - local only, which is the normal case"
  }
}

# ---- 6. autostart ----------------------------------------------------------
Head "[6/6] autostart"
if ($NoAutostart) {
  Say "skipped (-NoAutostart). Start it yourself with:  .\run.ps1"
} else {
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $here 'install-autostart.ps1')
}

# ---- 7. hand it over -------------------------------------------------------
# Everything up to here was bookkeeping. What is left is the part only a human
# can do - approving a browser extension - so get them to that one click and no
# further. The relay serves the userscript itself, which means Tampermonkey
# installs it from a URL and re-checks that same URL for updates afterwards.
Head "starting the relay"

$relayUp = $false
try {
  $probe = Invoke-WebRequest -Uri 'http://127.0.0.1:7355/health' -TimeoutSec 2 -UseBasicParsing
  if ($probe.StatusCode -eq 200) { $relayUp = $true; Say "already running" Green }
} catch { }

if (-not $relayUp) {
  Start-Process -FilePath 'powershell' `
    -ArgumentList @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass',
                    '-File', (Join-Path $here 'run.ps1')) `
    -WorkingDirectory $here | Out-Null
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 400
    try {
      $probe = Invoke-WebRequest -Uri 'http://127.0.0.1:7355/health' -TimeoutSec 2 -UseBasicParsing
      if ($probe.StatusCode -eq 200) { $relayUp = $true; break }
    } catch { }
  }
  if ($relayUp) { Say "relay running - leave that window open, it is also the log" Green }
  else { Say "relay did not come up. Start it yourself:  .\run.ps1" Yellow }
}

$installUrl = "http://127.0.0.1:7355/sniper.user.js?key=$key"

if ($relayUp -and -not $Quiet) {
  try { Start-Process $installUrl | Out-Null; Say "opened the install page in your browser" Green }
  catch { Say "open this yourself: $installUrl" Yellow }
}

Head "done - one click left"
Write-Host ""
Say "1. Install Tampermonkey, if you have not:" White
Say "     https://chromewebstore.google.com/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo" Cyan
Say "2. On the tab that just opened, click Install." White
Say "     (if no tab opened: $installUrl)" Gray
Say "3. Chrome 138+ only, and only if the buttons do not appear:" White
Say "     chrome://extensions -> Tampermonkey -> Details -> Allow User Scripts" Cyan
Write-Host ""
Say "Then open https://chat.deepseek.com or https://chat.qwen.ai and press Alt+R." White
Write-Host ""
Say "Console:      http://127.0.0.1:7355/console" Cyan
Say "Your project: http://127.0.0.1:7356/$EnvName/" Cyan
Say "Updates:      re-run this installer, then reopen the install URL above." Gray
Write-Host ""
Say "Check it worked:  $py selftest.py" White
Write-Host ""
