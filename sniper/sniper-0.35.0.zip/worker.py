#!/usr/bin/env python3
"""
worker.py - the local half of the hybrid. Bridges the cloud inbox to this disk.

    python worker.py                 poll forever
    python worker.py --once          one cycle, then exit
    python worker.py --publish-only  just push the current build up

Each cycle:
  1. pull claimed drops from the cloud and write them into drops\\
  2. (optionally) run the local placer over them
  3. ack the outcome of everything that left the queue, with its reason
  4. publish the current build so the game is playable from anywhere

It deliberately does nothing clever. Drops land in the same drops\\ directory
the userscript would have written to, so place.py, the Placer and the Gardener
all carry on working exactly as they do today - the cloud is a postbox, not a
second implementation.

Config: SNIPER_CLOUD (https://<app>.azurewebsites.net) and SNIPER_KEY, or
cloud.json next to this file.
"""

import argparse
import io
import json
import os
import sys
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
DROPS = os.path.join(ROOT, "drops")
CLOUD_CFG = os.path.join(ROOT, "cloud.json")
SEEN = os.path.join(ROOT, ".worker_seen.json")


def cfg():
    c = {}
    if os.path.exists(CLOUD_CFG):
        try:
            with open(CLOUD_CFG, encoding="utf-8") as fh:
                c = json.load(fh)
        except Exception as exc:
            print("  cloud.json unreadable: %s" % exc)
    base = os.environ.get("SNIPER_CLOUD") or c.get("url") or ""
    key = os.environ.get("SNIPER_KEY") or c.get("key") or ""
    return base.rstrip("/"), key, c


def call(base, key, path, payload=None, timeout=30):
    url = base + path
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data,
                                 method="POST" if data else "GET")
    req.add_header("X-Sniper-Key", key)
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8"))
        except Exception:
            return e.code, {}
    except Exception as exc:
        return 0, {"error": str(exc)}


def load_seen():
    try:
        with open(SEEN, encoding="utf-8") as fh:
            return set(json.load(fh))
    except Exception:
        return set()


def save_seen(s):
    with open(SEEN, "w", encoding="utf-8") as fh:
        json.dump(sorted(s)[-500:], fh)


def pull(base, key):
    """Bring cloud drops down into the local queue, untouched."""
    code, body = call(base, key, "/sync/pull")
    if code != 200 or not body.get("ok"):
        print("  pull failed (%s): %s" % (code, body.get("error")))
        return []
    os.makedirs(DROPS, exist_ok=True)
    landed = []
    for d in body.get("drops") or []:
        did = d.get("id")
        text = d.pop("text", "")
        if not did or not text:
            continue
        if os.path.exists(os.path.join(DROPS, did + ".json")):
            continue                      # already here from a previous cycle
        with io.open(os.path.join(DROPS, did + ".txt"), "w",
                     encoding="utf-8", newline="") as fh:
            fh.write(text)
        d["text_file"] = did + ".txt"
        with open(os.path.join(DROPS, did + ".json"), "w", encoding="utf-8") as fh:
            json.dump(d, fh, indent=2)
        landed.append(did)
    if landed:
        print("  pulled %d drop(s): %s" % (len(landed), ", ".join(landed[-3:])))
    return landed


def outcomes_for(ids):
    """What happened to drops that have left the queue, and why."""
    out = []
    for stage, label in (("applied", "applied"), ("rejected", "rejected")):
        d = os.path.join(ROOT, stage)
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if not f.endswith(".json"):
                continue
            did = f[:-5]
            if ids is not None and did not in ids:
                continue
            try:
                with open(os.path.join(d, f), encoding="utf-8") as fh:
                    m = json.load(fh)
            except Exception:
                continue
            out.append({"id": did, "outcome": label,
                        "reason": m.get("reason") or "applied",
                        "target": m.get("target"), "lines": m.get("lines")})
    return out


def current_env():
    """Follow the same config the relay and console follow - never a literal."""
    try:
        with open(os.path.join(ROOT, "config.json"), encoding="utf-8") as fh:
            name = (json.load(fh).get("current_env") or "").strip()
        if name:
            return name
    except Exception:
        pass
    try:
        with open(os.path.join(ROOT, "envs.json"), encoding="utf-8") as fh:
            names = sorted(json.load(fh))
        return names[0] if names else "demo"
    except Exception:
        return "demo"


def publish(base, key, name=None):
    name = name or current_env()
    """Push the current build up so it is playable from anywhere."""
    src = os.path.join(ROOT, "envs", name)
    if not os.path.isdir(src):
        print("  nothing to publish at envs/%s" % name)
        return
    files, total = {}, 0
    for fn in sorted(os.listdir(src)):
        p = os.path.join(src, fn)
        if not os.path.isfile(p) or os.path.splitext(fn)[1].lower() not in (
                ".html", ".htm", ".js", ".mjs", ".css", ".json", ".txt"):
            continue
        with io.open(p, encoding="utf-8", errors="replace") as fh:
            body = fh.read()
        total += len(body)
        files[fn] = body
        if total > 6 * 1024 * 1024:
            break
    if not files:
        return

    leads = None
    try:
        import subprocess
        import re as _re
        r = subprocess.run([sys.executable, os.path.join(ROOT, "gamecheck.py"),
                            os.path.join("envs", name, "index.html")],
                           capture_output=True, text=True, timeout=60, cwd=ROOT,
                           encoding="utf-8", errors="replace",
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        m = _re.search(r"^\s*(\d+) lead\(s\)", r.stdout or "", _re.M)
        leads = int(m.group(1)) if m else None
    except Exception:
        pass

    code, body = call(base, key, "/sync/publish",
                      {"name": name, "files": files, "leads": leads,
                       "lines": sum(v.count("\n") + 1 for v in files.values())},
                      timeout=120)
    if code == 200 and body.get("ok"):
        print("  published %s (%d file(s), leads=%s)"
              % (name, len(files), leads))
    else:
        print("  publish failed (%s): %s" % (code, body.get("error")))


def cycle(base, key, env, run_placer):
    seen = load_seen()
    landed = pull(base, key)
    seen |= set(landed)

    if landed and run_placer:
        # Ask the LOCAL relay to place them - it owns the agents and the files.
        code, body = call("http://127.0.0.1:7355", key, "/placeall",
                          {"model": "sonnet", "effort": "low"}, timeout=30)
        if code == 200 and body.get("started"):
            print("  local placer started on %d drop(s)" % body.get("count", 0))
        elif code == 409:
            print("  a run is already going - leaving it be")
        elif code:
            print("  placer not started (%s): %s" % (code, body.get("error")))

    acks = [o for o in outcomes_for(seen) if o["id"] in seen]
    if acks:
        code, body = call(base, key, "/sync/ack", {"results": acks})
        if code == 200:
            print("  acked %d outcome(s)" % body.get("acked", 0))
            seen -= {a["id"] for a in acks}
    save_seen(seen)
    publish(base, key, env)


def main():
    ap = argparse.ArgumentParser(description="sniper local worker")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--publish-only", action="store_true")
    ap.add_argument("--interval", type=int, default=20)
    ap.add_argument("--env", default=None,
                    help="environment to publish (default: config.json current_env)")
    ap.add_argument("--no-placer", action="store_true",
                    help="pull and ack, but leave placing to you")
    args = ap.parse_args()

    base, key, _ = cfg()
    if not base or not key:
        print("Set SNIPER_CLOUD and SNIPER_KEY, or write cloud.json:")
        print('  { "url": "https://<app>.azurewebsites.net", "key": "..." }')
        return 2

    code, body = call(base, key, "/health", timeout=20)
    if code != 200:
        print("cannot reach %s (%s): %s" % (base, code, body.get("error")))
        return 1
    print("worker -> %s   (%s drop(s) waiting)" % (base, body.get("drops")))

    if args.publish_only:
        publish(base, key, args.env)
        return 0

    while True:
        try:
            cycle(base, key, args.env, not args.no_placer)
        except KeyboardInterrupt:
            print("\nworker down")
            return 0
        except Exception as exc:
            print("  cycle error: %s" % exc)
        if args.once:
            return 0
        time.sleep(max(5, args.interval))


if __name__ == "__main__":
    sys.exit(main())
