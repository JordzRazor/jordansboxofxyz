#!/usr/bin/env python3
"""
place.py - the drop queue and the placement engine.

A drop moves:  drops/ -> working/ -> applied/ | rejected/

    python place.py list                    what is pending
    python place.py wait [--timeout 600]    BLOCK until a drop lands (cheap: no polling)
    python place.py show  <id>              metadata + full text
    python place.py claim <id>              atomically take it (multi-terminal safe)
    python place.py apply <id> [opts]       write it to disk, with a backup
    python place.py reject <id> "reason"    park it, unapplied
    python place.py auto                    drain every unambiguous drop, no model
    python place.py roots                   show the root map

apply options:
    --target PATH   override / supply the destination
    --mode  MODE    override the mode (new|replace|append)
    --dry-run       show what would happen, touch nothing
    --force         allow @new over an existing file

Placement is confined to the roots in roots.json. A target that resolves
outside them is refused - that check is the whole safety story, since drop
text is authored by a remote model.

This program NEVER executes drop content. It only writes files.
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import time
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.abspath(__file__))
DROPS = os.path.join(ROOT, "drops")
WORKING = os.path.join(ROOT, "working")
APPLIED = os.path.join(ROOT, "applied")
REJECTED = os.path.join(ROOT, "rejected")
BACKUPS = os.path.join(ROOT, "backups")
ROOTS_FILE = os.path.join(ROOT, "roots.json")
APPLY_LOG = os.path.join(ROOT, "applied.jsonl")
MANIFEST = os.path.join(DROPS, "manifest.jsonl")   # same log the relay appends to

DETERMINISTIC = ("new", "replace", "append")


def _now():
    return datetime.now(timezone.utc)


def load_roots() -> dict:
    with open(ROOTS_FILE, encoding="utf-8") as fh:
        raw = json.load(fh)
    return {k: os.path.abspath(v) for k, v in raw.items()}


def sha(path):
    if not os.path.exists(path):
        return None
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


# ---------------------------------------------------------------- queue ----
def _pair(stage, drop_id):
    return (os.path.join(stage, drop_id + ".json"),
            os.path.join(stage, drop_id + ".txt"))


def _read(stage, drop_id):
    meta_path, txt_path = _pair(stage, drop_id)
    if not os.path.exists(meta_path):
        return None, None
    with open(meta_path, encoding="utf-8") as fh:
        meta = json.load(fh)
    text = ""
    if os.path.exists(txt_path):
        with open(txt_path, encoding="utf-8", newline="") as fh:
            text = fh.read()
    return meta, text


def pending(stage=DROPS):
    if not os.path.isdir(stage):
        return []
    ids = sorted(f[:-5] for f in os.listdir(stage) if f.endswith(".json"))
    out = []
    for i in ids:
        meta, _ = _read(stage, i)
        if meta:
            out.append(meta)
    return out


def cmd_list(args):
    rows = pending(DROPS)
    work = pending(WORKING)
    if not rows and not work:
        print("queue empty")
        return 0
    if rows:
        print(f"\npending ({len(rows)}):")
        print(f"  {'ID':<40} {'MODE':<9} {'LINES':>5}  TARGET")
        for m in rows:
            print(f"  {m['id']:<40} {str(m.get('mode') or '-'):<9} "
                  f"{str(m.get('lines') or '?'):>5}  {m.get('target') or '(unaddressed)'}")
    if work:
        print(f"\nclaimed, not finished ({len(work)}):")
        for m in work:
            print(f"  {m['id']:<40} {m.get('target') or '(unaddressed)'}")
    print()
    return 0


def cmd_wait(args):
    """Block until something is pending. Cheap: the shell waits, not the model."""
    deadline = time.time() + args.timeout
    seen = {m["id"] for m in pending(DROPS)}
    if seen:
        print(f"{len(seen)} drop(s) already pending")
        return cmd_list(args)
    while time.time() < deadline:
        time.sleep(1.0)
        now = {m["id"] for m in pending(DROPS)}
        fresh = now - seen
        if fresh:
            print(f"drop landed: {', '.join(sorted(fresh))}")
            return cmd_list(args)
    print(f"nothing after {args.timeout}s")
    return 0


def cmd_show(args):
    for stage in (DROPS, WORKING):
        meta, text = _read(stage, args.id)
        if meta:
            print(json.dumps(meta, indent=2))
            print("-" * 60)
            print(text)
            return 0
    print(f"no such drop: {args.id}", file=sys.stderr)
    return 1


def cmd_claim(args):
    """Atomic: os.replace wins or raises, so two placers cannot both take one."""
    os.makedirs(WORKING, exist_ok=True)
    src_meta, src_txt = _pair(DROPS, args.id)
    dst_meta, dst_txt = _pair(WORKING, args.id)
    if not os.path.exists(src_meta):
        print(f"not pending (already claimed?): {args.id}", file=sys.stderr)
        return 1
    try:
        os.replace(src_meta, dst_meta)
    except OSError as exc:
        print(f"claim failed: {exc}", file=sys.stderr)
        return 1
    if os.path.exists(src_txt):
        os.replace(src_txt, dst_txt)
    print(f"claimed {args.id} (pid {os.getpid()})")
    return 0


def _park(drop_id, stage_to, extra):
    os.makedirs(stage_to, exist_ok=True)
    for src, dst in zip(_pair(WORKING, drop_id), _pair(stage_to, drop_id)):
        if os.path.exists(src):
            os.replace(src, dst)
    meta_path = _pair(stage_to, drop_id)[0]
    if os.path.exists(meta_path):
        with open(meta_path, encoding="utf-8") as fh:
            meta = json.load(fh)
        meta.update(extra)
        with open(meta_path, "w", encoding="utf-8") as fh:
            json.dump(meta, fh, indent=2)


def cmd_reject(args):
    meta, _ = _read(WORKING, args.id)
    if not meta:
        print(f"not claimed: {args.id} (claim it first)", file=sys.stderr)
        return 1
    _park(args.id, REJECTED, {"rejected_utc": _now().isoformat(),
                              "reason": args.reason})
    print(f"rejected {args.id}: {args.reason}")
    return 0


# ------------------------------------------------------------ resolution ----
def resolve(target: str, roots: dict):
    """Map a drop's target onto a real path, or explain why not.

    Returns (abs_path, None) or (None, reason).
    """
    if not target:
        return None, "drop is unaddressed - no target"
    t = target.strip().replace("/", os.sep).replace("\\", os.sep)

    if os.path.isabs(t):
        cand = os.path.abspath(t)
    else:
        head, _, rest = t.partition(os.sep)
        if head not in roots:
            return None, (f"first segment '{head}' is not a known root; "
                          f"known: {', '.join(sorted(roots))}")
        if not rest:
            return None, f"target '{target}' names a root, not a file"
        cand = os.path.abspath(os.path.join(roots[head], rest))

    for name, base in roots.items():
        try:
            if os.path.commonpath([cand, base]) == base:
                return cand, None
        except ValueError:
            continue          # different drive
    return None, f"resolved path escapes every root: {cand}"


# ----------------------------------------------------------------- apply ----
def cmd_apply(args):
    roots = load_roots()
    meta, text = _read(WORKING, args.id)
    if not meta:
        meta, text = _read(DROPS, args.id)
        if meta:
            print(f"drop {args.id} is not claimed - run: place.py claim {args.id}",
                  file=sys.stderr)
            return 1
        print(f"no such drop: {args.id}", file=sys.stderr)
        return 1

    target = args.target or meta.get("target")
    mode = (args.mode or meta.get("mode") or "replace").lower()

    if mode == "note":
        print("mode is @note - nothing to write by design")
        return 1
    if mode == "patch":
        print("mode is @patch - not deterministic; the placer must edit the "
              "target itself, then run: place.py reject <id> \"applied by hand\" "
              "or move it along.", file=sys.stderr)
        return 2
    if mode not in DETERMINISTIC:
        print(f"unknown mode '{mode}' (want one of {DETERMINISTIC})", file=sys.stderr)
        return 1

    path, why = resolve(target, roots)
    if not path:
        print(f"REFUSED: {why}", file=sys.stderr)
        return 1

    exists = os.path.exists(path)
    if mode == "new" and exists and not args.force:
        print(f"REFUSED: @new but file exists: {path}\n"
              f"         use --mode replace, or --force", file=sys.stderr)
        return 1

    before = sha(path)
    action = ("append to" if mode == "append" else
              "overwrite" if exists else "create")
    print(f"{'DRY-RUN: would ' if args.dry_run else ''}{action} {path}")
    print(f"  mode={mode}  bytes={len(text.encode('utf-8'))}  "
          f"lines={text.count(chr(10)) + 1}  sha_before={before}")
    if args.dry_run:
        return 0

    backup = None
    if exists:
        os.makedirs(BACKUPS, exist_ok=True)
        flat = path.replace(":", "").replace(os.sep, "_").lstrip("_")
        backup = os.path.join(BACKUPS, _now().strftime("%Y%m%d-%H%M%S-") + flat)
        shutil.copy2(path, backup)

    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "a" if mode == "append" else "w",
              encoding="utf-8", newline="") as fh:
        if mode == "append" and exists:
            fh.write("\n")
        fh.write(text)

    after = sha(path)
    record = {"id": args.id, "applied_utc": _now().isoformat(), "target": target,
              "path": path, "mode": mode, "backup": backup,
              "sha_before": before, "sha_after": after,
              "bytes": len(text.encode("utf-8")), "pid": os.getpid()}
    with open(APPLY_LOG, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\n")
    _park(args.id, APPLIED, {"applied": record})

    print(f"  wrote. sha_after={after}" + (f"  backup={backup}" if backup else ""))
    return 0


def cmd_auto(args):
    """Drain everything unambiguous, with no model in the loop at all."""
    roots = load_roots()
    rows = pending(DROPS)
    if not rows:
        print("queue empty")
        return 0
    done = skipped = 0
    for meta in rows:
        drop_id = meta["id"]
        mode = (meta.get("mode") or "").lower()
        target = meta.get("target")
        if mode not in DETERMINISTIC or not target:
            print(f"  skip {drop_id}: needs judgement "
                  f"(mode={mode or 'none'}, target={target or 'none'})")
            skipped += 1
            continue
        path, why = resolve(target, roots)
        if not path:
            print(f"  skip {drop_id}: {why}")
            skipped += 1
            continue
        ns = argparse.Namespace(id=drop_id, target=None, mode=None,
                                dry_run=args.dry_run, force=False)
        if cmd_claim(ns) != 0:
            skipped += 1
            continue
        if cmd_apply(ns) == 0:
            done += 1
        else:
            skipped += 1
    print(f"\nauto: {done} applied, {skipped} left for the placer")
    return 0


def cmd_propose(args):
    """Turn a fix into a DROP instead of editing the file.

    The Gardener diagnoses; the Placer applies. Routing everything through the
    queue means one write path, one backup trail, and a human sees the change
    in the console before it lands. It also means the Gardener needs no editing
    tool at all - the boundary stops being a promise.
    """
    roots = load_roots()
    path, why = resolve(args.target, roots)
    if not path:
        print(f"REFUSED: {why}", file=sys.stderr)
        return 1

    src = args.from_file
    if not os.path.exists(src):
        print(f"no such file: {src}", file=sys.stderr)
        return 1
    with io_open_text(src) as fh:
        text = fh.read()
    if not text.strip():
        print("refusing to propose an empty change", file=sys.stderr)
        return 1

    try:
        from relay import corruption_in
        bad = corruption_in(text)
    except Exception:
        bad = None
    if bad:
        print(f"REFUSED: the proposed text looks malformed - {bad}", file=sys.stderr)
        return 1

    os.makedirs(DROPS, exist_ok=True)
    now = _now()
    stamp = now.strftime("%Y%m%d-%H%M%S")
    n = len([f for f in os.listdir(DROPS) if f.endswith(".json")]) + 1
    label = re.sub(r"[^A-Za-z0-9]+", "-",
                   os.path.basename(args.target)).strip("-").lower() or "proposal"
    base = f"{stamp}-{n:03d}-{label}"

    record = {
        "id": base,
        "received_utc": now.isoformat(),
        "source": {"url": None, "title": f"proposed by {args.by}",
                   "site": "sniper", "kind": "proposal"},
        "lang": None,
        "target": args.target,
        "mode": args.mode,
        "note": args.note,
        "proposed_by": args.by,
        "finding": args.finding,
        "bytes": len(text.encode("utf-8")),
        "lines": text.count("\n") + 1,
        "text_file": base + ".txt",
    }
    with open(os.path.join(DROPS, base + ".txt"), "w",
              encoding="utf-8", newline="") as fh:
        fh.write(text)
    with open(os.path.join(DROPS, base + ".json"), "w", encoding="utf-8") as fh:
        json.dump(record, fh, indent=2)
    with open(MANIFEST, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\n")

    print(f"proposed {base}  -> {args.target}  @{args.mode}"
          f"  ({record['lines']} lines)")
    print("  it is in the queue now; the Placer applies it.")
    return 0


def io_open_text(p):
    return open(p, encoding="utf-8", newline="")


def cmd_backup(args):
    """Snapshot a file before editing it by hand.

    place.py apply backs up whatever it overwrites, but a @patch is applied
    with a normal editor, which would otherwise leave no way back.
    """
    roots = load_roots()
    path, why = resolve(args.target, roots)
    if not path:
        print(f"REFUSED: {why}", file=sys.stderr)
        return 1
    if not os.path.exists(path):
        print(f"nothing to back up (file does not exist): {path}")
        return 0
    os.makedirs(BACKUPS, exist_ok=True)
    flat = path.replace(":", "").replace(os.sep, "_").lstrip("_")
    dst = os.path.join(BACKUPS, _now().strftime("%Y%m%d-%H%M%S-") + flat)
    shutil.copy2(path, dst)
    print(f"backed up {path}\n       -> {dst}")
    return 0


def cmd_roots(args):
    for k, v in sorted(load_roots().items()):
        mark = "" if os.path.isdir(v) else "   [MISSING]"
        print(f"  {k:<22} {v}{mark}")
    return 0


def main():
    ap = argparse.ArgumentParser(description="sniper drop queue / placement engine")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list").set_defaults(fn=cmd_list)
    sub.add_parser("roots").set_defaults(fn=cmd_roots)

    w = sub.add_parser("wait")
    w.add_argument("--timeout", type=int, default=600)
    w.set_defaults(fn=cmd_wait)

    for name, fn in (("show", cmd_show), ("claim", cmd_claim)):
        p = sub.add_parser(name)
        p.add_argument("id")
        p.set_defaults(fn=fn)

    pr = sub.add_parser("propose")
    pr.add_argument("--target", required=True)
    pr.add_argument("--from", dest="from_file", required=True,
                    help="file holding the replacement text")
    pr.add_argument("--mode", default="patch",
                    choices=["patch", "replace", "new", "append"])
    pr.add_argument("--note", default=None, help="what this changes and why")
    pr.add_argument("--by", default="gardener")
    pr.add_argument("--finding", default=None, help="cache finding id, if any")
    pr.set_defaults(fn=cmd_propose)

    bk = sub.add_parser("backup")
    bk.add_argument("target")
    bk.set_defaults(fn=cmd_backup)

    r = sub.add_parser("reject")
    r.add_argument("id")
    r.add_argument("reason")
    r.set_defaults(fn=cmd_reject)

    a = sub.add_parser("apply")
    a.add_argument("id")
    a.add_argument("--target")
    a.add_argument("--mode")
    a.add_argument("--dry-run", action="store_true")
    a.add_argument("--force", action="store_true")
    a.set_defaults(fn=cmd_apply)

    au = sub.add_parser("auto")
    au.add_argument("--dry-run", action="store_true")
    au.set_defaults(fn=cmd_auto)

    args = ap.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
