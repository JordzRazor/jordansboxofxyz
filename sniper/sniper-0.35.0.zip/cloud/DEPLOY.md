# Deploying the sniper cloud inbox to Azure

This is the **cloud half** of a hybrid. It holds the queue, serves the console
and the published game, and hands work to a worker on your PC. It does **not**
run the Placer or the Gardener — those spawn `claude.exe` with your credentials,
take minutes, and edit files that only exist on your machine.

```
chat (anywhere) ──POST /drop──► Azure ──/sync/pull──► your PC (worker.py)
                                  ▲                        │
                                  └── /sync/ack, publish ──┘
```

## Build

```
python package.py --zip
```

That copies `app.py`, `console.html`, **the project's own `core.py`**,
`config.json` and `requirements.txt` into `dist/cloud/`, checks both Python
files parse and that the `app` callable exists, then zips it.

`core.py` is copied rather than duplicated on purpose: the cloud and the local
relay judge a capture corrupt with *the same file*, so they cannot drift.

## Create the app (free tier)

```
az group create --name sniper-rg --location westeurope

az appservice plan create --name sniper-plan --resource-group sniper-rg \
    --sku F1 --is-linux

az webapp create --resource-group sniper-rg --plan sniper-plan \
    --name <your-app-name> --runtime "PYTHON:3.12"
```

## Set the key — it will not start without one

```
az webapp config appsettings set --resource-group sniper-rg --name <your-app-name> \
    --settings SNIPER_KEY="<paste your .sniper_key>" SNIPER_DATA="/home/data"
```

Use the same value as your local `.sniper_key` so one key works everywhere.

## Deploy

```
az webapp deploy --resource-group sniper-rg --name <your-app-name> \
    --src-path dist/sniper-cloud.zip --type zip
```

Azure's Python image finds `app` in `app.py` and serves it with gunicorn. No
startup command needed.

Check it: `https://<your-app-name>.azurewebsites.net/health`

## Point the userscript at it

In `sniper.user.js`:

```js
const BASE = 'https://<your-app-name>.azurewebsites.net';
```

and add the host so Tampermonkey will allow the call:

```js
// @connect      <your-app-name>.azurewebsites.net
```

Everything else in the script is unchanged — the cloud speaks the same `/drop`
contract as the local relay.

## Run the worker on your PC

```
setx SNIPER_CLOUD https://<your-app-name>.azurewebsites.net
setx SNIPER_KEY <same key>
python worker.py
```

Or write `cloud.json` next to `worker.py`:

```json
{ "url": "https://<your-app-name>.azurewebsites.net", "key": "..." }
```

Useful flags: `--once` (one cycle), `--no-placer` (pull and ack but leave the
placing to you), `--publish-only`, `--interval 30`.

## What the free tier actually gives you

| | F1 |
|---|---|
| CPU | 60 minutes/day, shared |
| RAM | 1 GB |
| Storage | 1 GB at `/home`, **persists** across restarts |
| Always On | **not available** — the app sleeps after ~20 min idle |
| TLS | yes on `*.azurewebsites.net` |

The sleep is the one that bites: the first request after idle takes several
seconds while the container wakes. A worker polling every 20s keeps it warm,
which is usually what you want, and JSON requests this small barely touch the
CPU budget.

## Security notes, deliberately

- **The console is public** — it must load before you can type a key. It ships
  with **no secret in it** and asks for `SNIPER_KEY`, holding it in that
  browser's `localStorage` only. That is the opposite of the local console,
  which embeds the key because loopback is the boundary.
- Every route except `/health` and the console shell requires the key.
- `/sync/publish` takes **file names, never paths** — a compromised worker
  cannot write outside the published folder.
- Drop text is authored by a remote model. It is stored and displayed as data;
  the console renders it with `textContent`, never `innerHTML`.
- The corruption guard and the prose/code routing run here exactly as they do
  locally, because they are the same `core.py`.

## What is deliberately missing

No accounts, no multi-user separation, no cloud-side agents. One key, one
project, one person. Adding accounts is the prerequisite for anything else —
and note that an Anthropic **API key is not a Claude Code subscription**:
cloud-side agents would mean reimplementing the agent loop against the Messages
API and paying per token, which is why the worker keeps them local for now.
