#!/usr/bin/env python3
"""
sniper cloud inbox - the half of the pipeline that can live on a free web host.

    chat (anywhere) --POST /drop--> Azure --pull--> your PC's worker.py
                                      ^                    |
                                      +------ ack/publish -+

What it does: takes drops from the userscript, holds the queue, serves the
console and the published game, and hands work to a local worker.

What it deliberately does NOT do: run the Placer or the Gardener. Those spawn
claude.exe with your credentials and take minutes - there is no CLI on App
Service, and a 3-minute job does not fit a request. They stay on your machine,
which is also where your actual project files live.

WSGI, stdlib only (gunicorn is the sole dependency). Azure's Python App Service
looks for `app` in `app.py` and serves it with no configuration.

Storage lives under $SNIPER_DATA (default /home/data, which App Service keeps
across restarts). Auth is $SNIPER_KEY, sent as X-Sniper-Key.
"""

import hashlib
import hmac
import json
import mimetypes
import os
import re
from datetime import datetime, timezone  # noqa: F401  (datetime used by _repend_stale)
from urllib.parse import parse_qs

from core import (DEFAULT_ROUTING, corruption_in, parse_directive,
                  repair_mid_render, route_for, slugify)

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("SNIPER_DATA") or "/home/data"
if not os.path.isdir(os.path.dirname(DATA) or "/"):
    DATA = os.path.join(HERE, "data")          # local dev fallback

DROPS = os.path.join(DATA, "drops")
CONTEXT = os.path.join(DATA, "context")
REFUSED = os.path.join(DATA, "refused")
OUTCOMES = os.path.join(DATA, "outcomes")
PUBLISHED = os.path.join(DATA, "published")
for d in (DROPS, CONTEXT, REFUSED, OUTCOMES, PUBLISHED):
    os.makedirs(d, exist_ok=True)

KEY = os.environ.get("SNIPER_KEY") or ""
MAX_BODY = 8 * 1024 * 1024
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,120}$")


# --------------------------------------------------------------- plumbing --
def _now():
    return datetime.now(timezone.utc)


def _read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return default


def _rows(stage, limit=None):
    d = os.path.join(DATA, stage)
    if not os.path.isdir(d):
        return []
    ids = sorted((f[:-5] for f in os.listdir(d) if f.endswith(".json")),
                 reverse=bool(limit))
    out = []
    for i in (ids[:limit] if limit else ids):
        m = _read_json(os.path.join(d, i + ".json"))
        if m:
            out.append(m)
    return out


class Res:
    """Tiny response holder so handlers can just return data."""

    def __init__(self, status, body, ctype="application/json", extra=None):
        self.status = status
        self.body = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.ctype = ctype
        self.extra = extra or []


def ok(**kw):
    return Res("200 OK", dict(ok=True, **kw))


def err(status, message, **kw):
    return Res(status, dict(error=message, **kw))


# --------------------------------------------------------------- handlers --
def h_health(req):
    return ok(service="sniper-cloud", drops=len(_rows("drops")),
              published=sorted(os.listdir(PUBLISHED)) if os.path.isdir(PUBLISHED) else [],
              keyed=bool(KEY))


def h_drop(req):
    """Same contract as the local relay, so the userscript needs only a URL change."""
    p = req["json"]
    text = p.get("text")
    if not isinstance(text, str) or not text.strip():
        return err("400 Bad Request", "no text")

    # Prose is routed before any code-shaped check: an explanation has no
    # target and a stray paren in English means nothing.
    kind = p.get("kind") or "codeblock"
    routing = (_read_json(os.path.join(DATA, "config.json"), {}) or {}).get("routing")
    if route_for(kind, routing or DEFAULT_ROUTING) == "context":
        now = _now()
        base = now.strftime("%Y%m%d-%H%M%S-") + slugify(p.get("title") or "chat", 32)
        with open(os.path.join(CONTEXT, base + ".md"), "w",
                  encoding="utf-8", newline="") as fh:
            fh.write("<!-- from %s at %s -->\n\n" % (p.get("url") or "the chat",
                                                     now.isoformat()))
            fh.write(text)
        return ok(routed="context", id=base, lines=text.count("\n") + 1,
                  note="filed as context for the agents to read")

    target, mode, rest, body = parse_directive(text)

    bad = corruption_in(body)
    if bad and not p.get("force"):
        cand, removed = repair_mid_render(body)
        if removed and not corruption_in(cand):
            body, p["repaired"], p["removed"] = cand, True, removed
        else:
            return Res("422 Unprocessable Entity",
                       {"error": "looks like a mid-render capture", "detail": bad,
                        "hint": "ask for a ```javascript fence rather than ```text"})

    sha = hashlib.sha256(body.encode()).hexdigest()[:16]
    for m in _rows("drops"):
        if m.get("sha") == sha:
            return ok(duplicate=True, id=m["id"], target=target, mode=mode,
                      lines=body.count("\n") + 1)

    now = _now()
    n = len(_rows("drops")) + 1
    label = slugify((target or p.get("title") or "drop").rsplit("/", 1)[-1]
                    .rsplit("\\", 1)[-1])
    base = "%s-%03d-%s" % (now.strftime("%Y%m%d-%H%M%S"), n, label)
    rec = {"id": base, "received_utc": now.isoformat(),
           "source": {"url": p.get("url"), "title": p.get("title"),
                      "site": p.get("site"), "kind": kind},
           "lang": p.get("lang"), "target": target, "mode": mode, "note": rest,
           "bytes": len(body.encode()), "lines": body.count("\n") + 1, "sha": sha,
           "repaired": bool(p.get("repaired")),
           "removed_lines": (p.get("removed") or [])[:40],
           "text_file": base + ".txt", "state": "pending"}
    with open(os.path.join(DROPS, base + ".txt"), "w",
              encoding="utf-8", newline="") as fh:
        fh.write(body)
    with open(os.path.join(DROPS, base + ".json"), "w", encoding="utf-8") as fh:
        json.dump(rec, fh, indent=2)
    return ok(id=base, target=target, mode=mode, lines=rec["lines"])


def h_refused(req):
    p = req["json"]
    text = p.get("text") or ""
    if not text.strip():
        return err("400 Bad Request", "no text")
    now = _now()
    base = now.strftime("refused-%Y%m%d-%H%M%S")
    repaired, removed = repair_mid_render(text)
    rec = {"id": base, "utc": now.isoformat(),
           "reason": str(p.get("reason") or "")[:400], "url": p.get("url"),
           "lines": text.count("\n") + 1, "bytes": len(text.encode()),
           "still_wrong_after_repair": corruption_in(repaired),
           "repair_would_remove": removed[:20]}
    with open(os.path.join(REFUSED, base + ".txt"), "w",
              encoding="utf-8", newline="") as fh:
        fh.write(text)
    with open(os.path.join(REFUSED, base + ".json"), "w", encoding="utf-8") as fh:
        json.dump(rec, fh, indent=2)
    return ok(id=base, still_wrong_after_repair=rec["still_wrong_after_repair"])


def h_queue(req):
    return ok(pending=[m for m in _rows("drops") if m.get("state") == "pending"],
              claimed=[m for m in _rows("drops") if m.get("state") == "claimed"],
              outcomes=_rows("outcomes", limit=25),
              refused=_rows("refused", limit=10),
              context=sorted(os.listdir(CONTEXT), reverse=True)[:10]
              if os.path.isdir(CONTEXT) else [])


def h_droptext(req):
    drop_id = (req["query"].get("id") or [""])[0]
    if not ID_RE.match(drop_id or ""):
        return err("400 Bad Request", "bad id")
    p = os.path.join(DROPS, drop_id + ".txt")
    if not os.path.exists(p):
        return err("404 Not Found", "no such drop")
    with open(p, encoding="utf-8", newline="") as fh:
        return ok(id=drop_id, text=fh.read())


def h_routing(req):
    routing = dict(DEFAULT_ROUTING)
    routing.update((_read_json(os.path.join(DATA, "config.json"), {}) or {})
                   .get("routing") or {})
    return ok(routing=routing)


# ------------------------------------------------------------------ sync --
CLAIM_TIMEOUT_S = 600     # a claim nobody acks is a worker that died


def _repend_stale():
    """A claim is a promise to finish. If the worker is killed mid-cycle - or
    somebody pokes /sync/pull with curl - the drop would otherwise sit claimed
    forever and never reach a machine. Give the claim a lease instead.
    """
    now = _now()
    freed = []
    for m in _rows("drops"):
        if m.get("state") != "claimed":
            continue
        try:
            age = (now - datetime.fromisoformat(m["claimed_utc"])).total_seconds()
        except Exception:
            age = CLAIM_TIMEOUT_S + 1
        if age > CLAIM_TIMEOUT_S:
            m["state"] = "pending"
            m["note_sync"] = "claim expired after %ds - returned to the queue" % int(age)
            m.pop("claimed_utc", None)
            with open(os.path.join(DROPS, m["id"] + ".json"), "w",
                      encoding="utf-8") as fh:
                json.dump(m, fh, indent=2)
            freed.append(m["id"])
    return freed


def h_sync_pull(req):
    """What the local worker should take. Claiming here stops a second worker
    picking up the same drop."""
    claim = req["query"].get("claim", ["1"])[0] != "0"
    freed = _repend_stale()
    taken = []
    for m in _rows("drops"):
        if m.get("state") != "pending":
            continue
        p = os.path.join(DROPS, m["id"] + ".txt")
        with open(p, encoding="utf-8", newline="") as fh:
            m = dict(m, text=fh.read())
        if claim:
            rec = dict(m)
            rec.pop("text", None)
            rec["state"] = "claimed"
            rec["claimed_utc"] = _now().isoformat()
            with open(os.path.join(DROPS, m["id"] + ".json"), "w",
                      encoding="utf-8") as fh:
                json.dump(rec, fh, indent=2)
        taken.append(m)
    return ok(drops=taken, count=len(taken), reclaimed=freed)


def h_sync_ack(req):
    """The worker reporting what happened, so the console and the chat can see
    the reason a drop did or did not land."""
    p = req["json"]
    results = p.get("results") or []
    if not isinstance(results, list):
        return err("400 Bad Request", "results must be a list")
    written = 0
    for r in results:
        drop_id = r.get("id")
        if not isinstance(drop_id, str) or not ID_RE.match(drop_id):
            continue
        rec = {"id": drop_id, "utc": _now().isoformat(),
               "outcome": str(r.get("outcome") or "unknown")[:30],
               "reason": str(r.get("reason") or "")[:500],
               "target": r.get("target"), "lines": r.get("lines")}
        with open(os.path.join(OUTCOMES, drop_id + ".json"), "w",
                  encoding="utf-8") as fh:
            json.dump(rec, fh, indent=2)
        for ext in (".json", ".txt"):
            old = os.path.join(DROPS, drop_id + ext)
            if os.path.exists(old):
                try:
                    os.remove(old)
                except OSError:
                    pass
        written += 1
    return ok(acked=written)


def h_sync_publish(req):
    """The worker pushing the current build up so the game is playable from
    anywhere, plus whatever the health check says about it."""
    p = req["json"]
    name = str(p.get("name") or "zombie")
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,60}", name):
        return err("400 Bad Request", "bad name")
    files = p.get("files") or {}
    if not isinstance(files, dict) or not files:
        return err("400 Bad Request", "no files")
    root = os.path.join(PUBLISHED, name)
    os.makedirs(root, exist_ok=True)
    for rel, body in list(files.items())[:40]:
        if not isinstance(rel, str) or not isinstance(body, str):
            continue
        # names only, never paths - the worker cannot write outside here
        safe = os.path.basename(rel)
        if not safe or safe.startswith("."):
            continue
        with open(os.path.join(root, safe), "w", encoding="utf-8",
                  newline="") as fh:
            fh.write(body)
    meta = {"name": name, "utc": _now().isoformat(),
            "leads": p.get("leads"), "lines": p.get("lines"),
            "files": sorted(os.listdir(root))}
    with open(os.path.join(root, "_meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2)
    return ok(published=meta)


def h_game(req, rest):
    """Serve whatever the worker last published."""
    parts = [p for p in rest.split("/") if p and p != ".."]
    if not parts:
        return err("404 Not Found", "no game named")
    name, tail = parts[0], (parts[1] if len(parts) > 1 else "index.html")
    path = os.path.join(PUBLISHED, name, os.path.basename(tail))
    if not os.path.exists(path):
        return err("404 Not Found", "nothing published at %s" % name)
    ctype = mimetypes.guess_type(path)[0] or "text/plain"
    if path.endswith((".js", ".mjs")):
        ctype = "text/javascript"     # modules are refused without this
    with open(path, "rb") as fh:
        return Res("200 OK", fh.read(), ctype,
                   [("Cache-Control", "no-store")])


def h_console(req):
    try:
        with open(os.path.join(HERE, "console.html"), "rb") as fh:
            return Res("200 OK", fh.read(), "text/html; charset=utf-8",
                       [("Cache-Control", "no-store")])
    except FileNotFoundError:
        return err("404 Not Found", "console.html missing")


# The console is PUBLIC (it must load before you can type the key), so it ships
# with no secret in it. Everything else needs the header.
OPEN = {"/health", "/", "/console"}
GETS = {"/health": h_health, "/queue": h_queue, "/droptext": h_droptext,
        "/routing": h_routing, "/sync/pull": h_sync_pull, "/console": h_console,
        "/": h_console}
POSTS = {"/drop": h_drop, "/refused": h_refused,
         "/sync/ack": h_sync_ack, "/sync/publish": h_sync_publish}


def app(environ, start_response):
    path = environ.get("PATH_INFO", "/").rstrip("/") or "/"
    method = environ.get("REQUEST_METHOD", "GET").upper()
    req = {"query": parse_qs(environ.get("QUERY_STRING", "")), "json": {}}

    if method == "OPTIONS":
        res = Res("204 No Content", b"", "text/plain")
    elif not KEY:
        res = err("500 Internal Server Error",
                  "SNIPER_KEY is not set on this app - see DEPLOY.md")
    else:
        supplied = environ.get("HTTP_X_SNIPER_KEY", "")
        authed = hmac.compare_digest(supplied, KEY)
        if path not in OPEN and not authed:
            res = err("401 Unauthorized", "bad key")
        elif path.startswith("/game/"):
            res = h_game(req, path[len("/game/"):])
        elif method == "GET" and path in GETS:
            res = GETS[path](req)
        elif method == "POST" and path in POSTS:
            try:
                n = int(environ.get("CONTENT_LENGTH") or 0)
            except ValueError:
                n = 0
            if n <= 0:
                res = err("400 Bad Request", "empty body")
            elif n > MAX_BODY:
                res = err("413 Payload Too Large", "body over %d bytes" % MAX_BODY)
            else:
                try:
                    req["json"] = json.loads(
                        environ["wsgi.input"].read(n).decode("utf-8-sig"))
                    res = POSTS[path](req)
                except Exception as exc:
                    res = err("400 Bad Request", "bad json: %s" % exc)
        else:
            res = err("404 Not Found", "no such endpoint")

    headers = [("Content-Type", res.ctype),
               ("Content-Length", str(len(res.body))),
               ("Access-Control-Allow-Origin", "*"),
               ("Access-Control-Allow-Headers", "Content-Type, X-Sniper-Key"),
               ("Access-Control-Allow-Methods", "GET, POST, OPTIONS")] + res.extra
    start_response(res.status, headers)
    return [res.body]


if __name__ == "__main__":
    # Local testing only - on Azure, gunicorn imports `app` and owns the socket.
    from wsgiref.simple_server import make_server, WSGIServer

    class SoleServer(WSGIServer):
        # Windows honours SO_REUSEADDR by letting a SECOND process bind a port
        # that is already taken, so two builds end up alternating replies and
        # you debug a ghost. Refuse instead.
        allow_reuse_address = False

    port = int(os.environ.get("PORT", "8000"))
    try:
        srv = make_server("0.0.0.0", port, app, server_class=SoleServer)
    except OSError as exc:
        print("port %d is already in use (%s) - stop the other instance first"
              % (port, exc))
        raise SystemExit(1)
    print("sniper cloud on http://127.0.0.1:%d   data=%s" % (port, DATA))
    srv.serve_forever()
