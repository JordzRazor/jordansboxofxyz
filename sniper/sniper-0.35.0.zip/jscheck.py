#!/usr/bin/env python3
"""
jscheck.py - delimiter balance for JavaScript, done lexically.

    python jscheck.py sniper.user.js
    python jscheck.py envs/zombie/index.html      (scans <script> blocks)

There is no JS runtime on this machine, so a syntax error in the userscript is
invisible until Tampermonkey silently refuses to run it. Counting braces with a
regex does not work either: this code is full of template literals with `${}`
interpolation, and a naive scrubber reports known-good files as unbalanced -
which is exactly how an hour gets wasted arguing with a broken instrument.

So: a real (small) lexer. It tracks strings, template literals INCLUDING nested
`${ ... }`, comments, and regex literals, and only counts delimiters that are
actually code. It reports the line of the first unmatched one.

Not a parser - it will not catch `if (a b)`. It catches the thing that actually
breaks a hand-edited file: a delimiter that never closes.
"""

import re
import sys

# A '/' begins a regex (not a division) when the last meaningful token is one of
# these - the standard heuristic, and good enough for hand-written code.
REGEX_OK_AFTER = set("(,=:[!&|?{};+-*%~^<>") | {"return", "typeof", "instanceof",
                                                "in", "of", "new", "delete",
                                                "void", "case", "do", "else",
                                                "yield", "await"}


def scan(src):
    """Yield (index, char) for characters that are real code."""
    i, n = 0, len(src)
    depth_stack = []          # '`' while inside a template literal
    last_sig = ""             # last significant token, for the regex heuristic
    out = []

    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""

        # comments
        if c == "/" and nxt == "/":
            i = src.find("\n", i)
            if i < 0:
                break
            continue
        if c == "/" and nxt == "*":
            j = src.find("*/", i + 2)
            i = (j + 2) if j >= 0 else n
            continue

        # strings
        if c in "'\"":
            q, i = c, i + 1
            while i < n:
                if src[i] == "\\":
                    i += 2
                    continue
                if src[i] == q:
                    i += 1
                    break
                i += 1
            last_sig = "str"
            continue

        # template literal - may contain ${ ... } holding real code
        if c == "`":
            i += 1
            while i < n:
                if src[i] == "\\":
                    i += 2
                    continue
                if src[i] == "`":
                    i += 1
                    break
                if src[i] == "$" and i + 1 < n and src[i + 1] == "{":
                    # recurse into the interpolation: it IS code
                    depth, j = 1, i + 2
                    while j < n and depth:
                        if src[j] == "{":
                            depth += 1
                        elif src[j] == "}":
                            depth -= 1
                        elif src[j] in "'\"`":
                            q2 = src[j]
                            j += 1
                            while j < n:
                                if src[j] == "\\":
                                    j += 2
                                    continue
                                if src[j] == q2:
                                    break
                                j += 1
                        j += 1
                    out.extend(scan(src[i + 2:j - 1]))
                    i = j
                    continue
                i += 1
            last_sig = "tpl"
            continue

        # regex literal
        if c == "/" and (last_sig[-1:] in REGEX_OK_AFTER or last_sig in REGEX_OK_AFTER
                         or last_sig == ""):
            j, in_class = i + 1, False
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == "[":
                    in_class = True
                elif src[j] == "]":
                    in_class = False
                elif src[j] == "/" and not in_class:
                    break
                elif src[j] == "\n":
                    j = i          # not a regex after all
                    break
                j += 1
            if j > i:
                i = j + 1
                last_sig = "re"
                continue

        if c in "(){}[]":
            out.append((i, c))
            last_sig = c
        elif not c.isspace():
            last_sig = c if not c.isalnum() else (last_sig + c)[-12:]
        i += 1
    return out


def blocks_of(path, src):
    if not path.lower().endswith((".html", ".htm")):
        return [(src, 0)]
    out = []
    for m in re.finditer(r"<script\b[^>]*>(.*?)</script>", src, re.S | re.I):
        if "importmap" in m.group(0)[:120].lower():
            continue
        out.append((m.group(1), m.start(1)))
    return out


def check(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        src = fh.read()

    problems = 0
    for body, offset in blocks_of(path, src):
        stack = []
        pairs = {")": "(", "}": "{", "]": "["}
        for idx, ch in scan(body):
            if ch in "({[":
                stack.append((idx, ch))
            else:
                if not stack:
                    line = src.count("\n", 0, offset + idx) + 1
                    print(f"  {path}:{line}  unexpected {ch!r}")
                    problems += 1
                elif stack[-1][1] != pairs[ch]:
                    line = src.count("\n", 0, offset + idx) + 1
                    print(f"  {path}:{line}  {ch!r} closes {stack[-1][1]!r}")
                    problems += 1
                    stack.pop()
                else:
                    stack.pop()
        for idx, ch in stack:
            line = src.count("\n", 0, offset + idx) + 1
            print(f"  {path}:{line}  {ch!r} is never closed")
            problems += 1

    print(f"  [{'FAIL' if problems else 'PASS'}] {path} - "
          f"{problems or 'no'} unmatched delimiter(s)")
    return problems


if __name__ == "__main__":
    targets = sys.argv[1:] or ["sniper.user.js"]
    sys.exit(1 if sum(check(t) for t in targets) else 0)
