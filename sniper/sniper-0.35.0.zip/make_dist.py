#!/usr/bin/env python3
"""
make_dist.py - build the distributable zip.

    python make_dist.py            -> dist/sniper-<version>.zip

Ships CODE ONLY. Everything about this particular install stays behind: the
shared key, roots.json full of one person's folders, the drop queue, the
context files, the backups, the game. Those are either private or meaningless
on someone else's machine.

The list below is an ALLOWLIST on purpose. An ignore-list ships whatever you
forgot to think about, and the thing you forget is usually the secret.
"""

import hashlib
import io
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, "dist")

# Only these leave the building.
SHIP = [
    "relay.py", "core.py", "place.py", "cache.py", "gamecheck.py",
    "jscheck.py", "lint_names.py", "selftest.py", "flowtest.py", "worker.py",
    "package.py", "make_dist.py", "stamp.py", "routetest.py",
    "console.html", "sniper.user.js", "starter.html", "test_monaco.js",
    "config.json", "sites.json",
    "CLAUDE.md", "README.md", "VERSION", "VERSION.sha",
    "run.ps1", "tray.ps1", "placer.ps1", "install-autostart.ps1",
    # The front door. START-HERE.bat is what someone double-clicks on a machine
    # with nothing on it, and INSTALL.txt is what they read if they open the zip
    # first - plain text on purpose, because it has to be legible before any of
    # this is installed.
    "START-HERE.bat", "INSTALL.txt",
    "install.ps1", "INSTALL.md",
    "cloud/app.py", "cloud/console.html", "cloud/requirements.txt",
    "cloud/DEPLOY.md",
]

# Generated per install, never shipped. Named so the check below can shout
# if one ever sneaks into SHIP.
NEVER = {".sniper_key", "roots.json", "envs.json", "cache.json", "cloud.json",
         "bindings.json",
         ".worker_seen.json", "applied.jsonl"}
NEVER_DIRS = {"drops", "working", "applied", "rejected", "refused", "context",
              "diag", "runs", "backups", "proposals", "envs", "__pycache__",
              "dist", "scratch", "data"}


def version():
    try:
        with io.open(os.path.join(ROOT, "VERSION"), encoding="utf-8") as fh:
            return fh.read().strip()
    except Exception:
        return "0.0.0"


def check_secrets(name, data):
    """Refuse to ship anything carrying this machine's identity."""
    text = data.decode("utf-8", "replace")
    problems = []

    # the real key, read from disk so the check cannot drift from reality
    try:
        with io.open(os.path.join(ROOT, ".sniper_key"), encoding="ascii") as fh:
            key = fh.read().strip()
        if key and key in text:
            problems.append("contains this install's .sniper_key")
    except Exception:
        pass

    # Docs legitimately show example paths. These stand for "whoever you are"
    # and are the only user segments allowed out of the building.
    PLACEHOLDERS = {"you", "user", "username", "yourname", "me", "name"}
    for m in re.findall(r"[A-Za-z]:[\\/]Users[\\/]([A-Za-z0-9_.<>-]+)", text):
        seg = m.strip("<>").lower()
        if seg not in PLACEHOLDERS:
            problems.append("hardcodes a user path segment: %s" % m)
            break
    return problems


def check_versions():
    """Two versions live here, and they are NOT the same number.

    VERSION          the project: relay.py, console.html, the userscript, all
                     of it. Moves whenever anything ships.
    @version         the userscript's own version, and the ONLY thing
                     Tampermonkey compares. It must move when, and only when,
                     the script's bytes move - a bump with no change makes
                     "update available" mean nothing, and a change with no bump
                     leaves two different builds wearing one number.
    const VERSION    the same userscript version, in the place the running
                     script actually reports from - its toast, its console
                     line, and script_version on every census.

    An earlier version of this check required all three to be equal. That was
    wrong: it meant a relay-only fix could not ship without forcing a reinstall
    of a userscript that had not changed. The real invariants are narrower -
    the two numbers INSIDE the script agree with each other, and the script's
    bytes have not moved since its own version was stamped.
    """
    try:
        with io.open(os.path.join(ROOT, "sniper.user.js"), encoding="utf-8") as fh:
            js = fh.read()
    except Exception as exc:
        return ["could not read sniper.user.js: %s" % exc]

    head = re.search(r"^//\s*@version\s+(\S+)", js, re.M)
    const = re.search(r"const\s+VERSION\s*=\s*['\"]([^'\"]+)['\"]", js)
    head_v = head.group(1) if head else None
    const_v = const.group(1) if const else None

    if not head_v or not const_v:
        return ["sniper.user.js is missing @version or const VERSION"]
    if head_v != const_v:
        return ["the userscript disagrees with itself: @version=%s but "
                "const VERSION=%s - the browser would install one number and "
                "report the other" % (head_v, const_v)]

    live = hashlib.sha256(js.encode("utf-8")).hexdigest()[:16]
    try:
        with io.open(os.path.join(ROOT, "VERSION.sha"), encoding="utf-8") as fh:
            stamped_ver, stamped_sha = fh.read().split()
    except Exception:
        return ["VERSION.sha is missing - run: python stamp.py"]
    if stamped_ver != head_v:
        return ["VERSION.sha records userscript %s but the script says %s - "
                "run: python stamp.py" % (stamped_ver, head_v)]
    if stamped_sha != live:
        return ["sniper.user.js changed since %s was stamped (%s -> %s). "
                "Bump @version and const VERSION, then: python stamp.py"
                % (head_v, stamped_sha, live)]
    return []


def build():
    ver = version()
    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, "sniper-%s.zip" % ver)

    drift = check_versions()
    if drift:
        for d in drift:
            print("  %s" % d, file=sys.stderr)
        return 1

    missing = [p for p in SHIP if not os.path.exists(os.path.join(ROOT, p))]
    if missing:
        for m in missing:
            print("  MISSING %s" % m, file=sys.stderr)
        return 1

    bad = [p for p in SHIP if os.path.basename(p) in NEVER
           or p.split("/")[0] in NEVER_DIRS]
    if bad:
        print("  SHIP list contains things that must never ship: %s" % bad,
              file=sys.stderr)
        return 1

    total, flagged = 0, 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in SHIP:
            src = os.path.join(ROOT, rel)
            with open(src, "rb") as fh:
                data = fh.read()

            # The userscript must go out with a placeholder, not a live key.
            if rel == "sniper.user.js":
                data = re.sub(rb"const KEY   = '[^']*';",
                              b"const KEY   = '__SNIPER_KEY__';", data)

            problems = check_secrets(rel, data)
            if problems:
                for p in problems:
                    print("  REFUSED %s - %s" % (rel, p), file=sys.stderr)
                flagged += 1
                continue

            z.writestr(rel.replace("\\", "/"), data)
            total += len(data)
            print("  %-34s %9s bytes" % (rel, format(len(data), ",")))

    if flagged:
        os.remove(out)
        print("\n  %d file(s) refused - zip deleted rather than ship a secret"
              % flagged, file=sys.stderr)
        return 1

    print("\n  %s  (%s bytes from %s of source)"
          % (out, format(os.path.getsize(out), ","), format(total, ",")))
    print("  version %s, %d files" % (ver, len(SHIP)))
    return 0


if __name__ == "__main__":
    sys.exit(build())
