#!/usr/bin/env python3
"""
core.py - logic with no machine underneath it.

Everything here is a pure function over text: no filesystem, no subprocess, no
config. That is the whole point - the local relay and the cloud inbox both
import this module, so a capture judged corrupt on your PC is judged corrupt in
Azure by the identical code rather than by a lookalike reimplementation.

If you are tempted to add an `open()` or a `subprocess` here, it belongs
somewhere else.
"""

import re

# ---------------------------------------------------------------- directives --
# first line may address a drop:  // >> path\to\file.py @replace
DIRECTIVE = re.compile(
    r"""^[ \t]*(?://|\#|--|;|%|<!--|/\*)?[ \t]*>>[ \t]*
        (?P<target>\S+)
        (?:[ \t]+@(?P<mode>replace|new|append|patch|note))?
        (?:[ \t]+(?P<rest>.*?))?
        [ \t]*(?:-->|\*/)?[ \t]*$""",
    re.VERBOSE,
)


def parse_directive(text: str):
    """Pull a self-addressing first line off a drop, if present.

    Returns (target, mode, rest, body_without_the_directive_line). The line is
    stripped so what remains is ready to place verbatim.
    """
    lines = text.split("\n", 1)
    m = DIRECTIVE.match(lines[0]) if lines else None
    if not m:
        return None, None, None, text
    body = lines[1] if len(lines) > 1 else ""
    return (m.group("target"), m.group("mode") or "replace",
            (m.group("rest") or "").strip() or None, body)


# ---------------------------------------------------------------- integrity --
# An html document announces itself in its first bytes. Used to tell a cut-off
# document apart from a legitimate fragment.
HTML_OPENS = re.compile(r"\s*(<!doctype\s+html|<html[\s>])", re.I)


def corruption_in(text: str):
    """Spot a mid-render capture by its SHAPE, not by its stability.

    A chat UI can leave stale nodes inside a code block while it re-renders, so
    the text settles into a consistently wrong state - two identical reads prove
    nothing. The signature is structural: a line repeated verbatim, or followed
    by a truncated copy of itself.

    Raw lines, not stripped: stripping would flag legitimate nested closing
    braces. Only ever run this on CODE - prose has neither property, and an
    English sentence containing "Math.max(a, b" is not corrupt.
    """
    lines = text.split("\n")
    for i in range(len(lines) - 1):
        a, b = lines[i], lines[i + 1]
        if not a.strip():
            continue
        if a == b and len(a.strip()) > 1:
            return f"line {i + 2} repeats line {i + 1} verbatim: {a.strip()[:60]!r}"
        if 12 < len(b) < len(a) and a.startswith(b):
            return f"line {i + 2} is a truncated copy of line {i + 1}: {b.strip()[:60]!r}"

    # A lone truncated line has no duplicate to give it away, but it leaves
    # delimiters hanging open. POSITIVE imbalance only: a fragment that closes
    # more than it opens is normal when replacing the tail of a block, and
    # braces are excluded entirely for the same reason.
    for name, op, cl in (("parenthesis", "(", ")"), ("bracket", "[", "]")):
        d = text.count(op) - text.count(cl)
        if d > 0:
            tail = [l for l in lines if l.strip()]
            return (f"{d} unclosed {name}{'' if d == 1 else 'es'} - looks cut off"
                    + (f", ends: {tail[-1].strip()[:60]!r}" if tail else ""))
    # A block that OPENS an html document but never closes it is cut off,
    # not corrupt in the repeated-line sense: a virtualised code block only
    # mounts what is on screen, so the read stops where the DOM does. Only
    # fires when the text STARTS a document, so a fragment is exempt.
    if HTML_OPENS.match(text[:400]) and "</html>" not in text[-4000:].lower():
        return "opens an html document but never closes </html> - it is cut off"

    return None


def repair_mid_render(text: str):
    """Undo a bad render: drop lines the previous KEPT line fully contains.

    Conservative by construction, and the caller must re-verify with
    corruption_in() before trusting the result. Note that a repair can still be
    semantically wrong while being structurally clean - it has produced broken
    template literals before. Prefer fixing the source (ask for a ```javascript
    fence) over relying on this.
    """
    out, removed = [], []
    for cur in text.split("\n"):
        prev = out[-1] if out else None
        if (prev is not None and cur.strip() and prev.strip()
                and (cur == prev or (len(cur) < len(prev) and prev.startswith(cur)))):
            removed.append(cur.strip()[:60])
            continue
        out.append(cur)
    return "\n".join(out), removed


# -------------------------------------------------------------------- misc --
def slugify(s: str, limit: int = 40) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", (s or "")).strip("-").lower()
    return (s[:limit].rstrip("-")) or "drop"


def fence_for(text: str) -> str:
    """A fence longer than any backtick run inside the text, so a code block in
    the content cannot terminate the block wrapping it."""
    longest = run = 0
    for ch in text:
        run = run + 1 if ch == "`" else 0
        longest = max(longest, run)
    return "`" * max(3, longest + 1)


DEFAULT_ROUTING = {"codeblock": "queue", "proposal": "queue",
                   "selection": "queue", "message": "context"}


def route_for(kind: str, routing: dict = None) -> str:
    """Where a snipe of this kind belongs. A code block is work; an explanation
    is why the work is shaped that way, and must never be written to a file."""
    table = dict(DEFAULT_ROUTING)
    table.update(routing or {})
    return table.get(kind or "codeblock", "queue")
