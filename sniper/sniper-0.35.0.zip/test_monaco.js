// Pulls the pure Monaco readers out of sniper.user.js and runs them against a
// fake Monaco DOM: recycled line divs in shuffled DOM order, a gutter column
// keyed only by `top`, and a .lines-content spacer sized to the whole file.
const fs = require('fs');
const src = fs.readFileSync(process.argv[2] || 'sniper.user.js', 'utf8');

function grab(name) {
  const head = src.indexOf('function ' + name + '(');
  if (head < 0) throw new Error('no such function: ' + name);
  let i = src.indexOf('{', head), depth = 0;
  for (let j = i; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (!depth) return src.slice(head, j + 1); }
  }
  throw new Error('unbalanced: ' + name);
}

const NBSP = ' ';
const LH = 19;

// --- the smallest DOM that can be wrong in the ways that matter -------------
function node(cls, top, text, kids) {
  return {
    className: cls, style: { top: top === null ? '' : top + 'px' },
    textContent: text, _kids: kids || [],
    getBoundingClientRect: () => ({ height: LH }),
  };
}

function makeEditor(total, mounted, spacerPx) {
  const lineDivs = [], gutterDivs = [];
  for (const n of mounted) {
    const top = (n - 1) * LH;
    lineDivs.push(node('view-line', top, NBSP.repeat(4) + 'line ' + n + ' code();'));
    gutterDivs.push(node('gutter', top, String(n)));
  }
  // Monaco recycles line divs, so DOM order is not reading order. Shuffle
  // hard, and shuffle the two columns DIFFERENTLY - if the join secretly
  // relied on index rather than `top`, this is what catches it.
  lineDivs.reverse();
  gutterDivs.sort(() => 0.3 - Math.random());

  const spacer = node('lines-content', null, '');
  // Monaco does not always size this to the document - see test 5.
  spacer.style.height = (spacerPx == null ? total * LH : spacerPx) + 'px';

  return {
    querySelector(sel) {
      if (sel === '.view-lines') return { querySelectorAll: (s) => (s === '.view-line' ? lineDivs : []) };
      if (sel === '.lines-content') return spacer;
      if (sel === '.view-line') return lineDivs[0] || null;
      return null;
    },
    querySelectorAll(sel) {
      return sel === '.margin-view-overlays > div' ? gutterDivs : [];
    },
  };
}

const ctx = { Number, Map, Math, parseFloat, parseInt, String, Array };

// monacoShape closes over two module consts. The extracted copy runs in global
// scope here, so lift the real values out of the source rather than restating
// them - a test that hardcodes the ceiling cannot notice it moving.
for (const name of ['MAX_ELEMENT_PX', 'MAX_PLAUSIBLE_LINES']) {
  const head = 'const ' + name + ' = ';
  const i = src.indexOf(head);
  if (i < 0) throw new Error('no such const: ' + name);
  globalThis[name] = Number(src.slice(i + head.length, src.indexOf(';', i)));
}
const monacoRows     = new Function('return ' + grab('monacoRows'))();
const monacoShape    = new Function('return ' + grab('monacoShape'))();
const monacoAssemble = new Function('return ' + grab('monacoAssemble'))();

let failures = 0;
function check(label, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  if (!ok) failures++;
  console.log((ok ? '  ok   ' : '  FAIL ') + label
    + (ok ? '' : '\n         got  ' + JSON.stringify(got)
             + '\n         want ' + JSON.stringify(want)));
}

// --- 1. the refusal we actually got: 29 of 152 lines mounted ---------------
{
  const ed = makeEditor(152, [24, 25, 26, 27, 28, 29]);
  const rows = new Map();
  const added = monacoRows(ed, rows);
  const shape = monacoShape(ed);
  const built = monacoAssemble(rows, shape.total);

  check('learns one entry per mounted line', added, 6);
  check('reads the document length off the spacer', shape.total, 152);
  check('a plausible spacer is trusted', shape.trusted, true);
  check('measures the line height', shape.lineH, LH);
  check('joins text to number by top, not by DOM order',
        rows.get(27), '    line 27 code();');
  check('counts what it has', [built.have, built.total], [6, 152]);
  check('names the holes', built.gaps, ['1-23', '30-152']);
  const lines = built.text.split('\n');
  check('places a mounted line at its own index', lines[26], '    line 27 code();');
  check('leaves a hole blank rather than shifting the file up', lines[0], '');
}

// --- 2. everything mounted: the case the fix has to produce ----------------
{
  const all = [];
  for (let i = 1; i <= 152; i++) all.push(i);
  const ed = makeEditor(152, all);
  const rows = new Map();
  monacoRows(ed, rows);
  const built = monacoAssemble(rows, monacoShape(ed).total);

  check('no gaps when every line mounted', built.gaps, []);
  check('has the whole document', [built.have, built.total], [152, 152]);
  const lines = built.text.split('\n');
  check('line count matches', lines.length, 152);
  check('first line is line 1', lines[0], '    line 1 code();');
  check('last line is line 152', lines[151], '    line 152 code();');
  let ordered = true;
  for (let i = 0; i < 152; i++)
    if (lines[i] !== '    line ' + (i + 1) + ' code();') ordered = false;
  check('reading order restored from shuffled DOM', ordered, true);
}

// --- 3. merging across scroll steps ---------------------------------------
{
  const rows = new Map();
  monacoRows(makeEditor(152, [1, 2, 3]), rows);
  monacoRows(makeEditor(152, [3, 4, 5]), rows);     // overlap, as a real scroll gives
  const built = monacoAssemble(rows, 152);
  check('merges steps without duplicating the overlap', built.have, 5);
  check('gap after the merged run', built.gaps, ['6-152']);
}

// --- 4. NBSP is normalised, trailing space dropped -------------------------
{
  const ed = makeEditor(3, [1, 2, 3]);
  const rows = new Map();
  monacoRows(ed, rows);
  check('NBSP became a real space', /^ {4}line 1/.test(rows.get(1)), true);
  check('no NBSP survives', rows.get(1).indexOf(NBSP), -1);
}

// --- 5. the spacer is the browser's ceiling, not the document -------------
// Measured on Qwen 2026-09-12: .lines-content came back 16777200px - 2^24-16,
// the engine's maximum element height, not a length Monaco chose. At 20px a
// line that is 838,860 imaginary lines, so a COMPLETE 243-line capture ending
// in </html> was refused for "missing 244-838860", and the assembler built
// 847KB that was 99.98% blank. The spacer is a hint; the gutter is the truth.
{
  const mounted = [];
  for (let i = 1; i <= 243; i++) mounted.push(i);
  const ed = makeEditor(243, mounted, 16777200);
  const shape = monacoShape(ed);

  check('an impossible spacer is not trusted', shape.trusted, false);
  check('so it yields no total at all', shape.total, 0);
  // 838,860 in the wild, where the line is 20px; here the fake line is LH.
  check('while still reporting what it saw',
        shape.spacerLines, Math.round(16777200 / LH));

  const rows = new Map();
  monacoRows(ed, rows);
  const built = monacoAssemble(rows, shape.total);

  check('the gutter supplies the length instead',
        [built.have, built.total], [243, 243]);
  check('no phantom trailing gap', built.gaps, []);
  check('the text is the document, not a blank field',
        built.text.split('\n').length, 243);
  check('and it is therefore complete', built.have >= built.total, true);
}

console.log(failures ? '\n' + failures + ' FAILED' : '\nall passed');
process.exit(failures ? 1 : 0);
