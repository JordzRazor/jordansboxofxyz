#!/usr/bin/env python3
r"""
routetest - exercise /paste and /clear against a relay of its own.

    py -3 routetest.py

Unlike selftest and flowtest, this one does NOT talk to your relay. It stands
up a second one on ports 7395/7396 in a throwaway copy of the project and
tests that. It has to: /clear empties a stage, and a regression suite that can
empty your real queue is not a regression suite, it is an accident waiting.

What it covers:
  /paste  - the floor under every capture route. A page that will not hand its
            text over (Qwen renders code into a Monaco editor that only keeps
            the lines on screen) is no longer the end of the road: copy the
            block, paste it here, and it stages like anything sniped, first
            line directive and all.
  /clear  - tidying the queue. Nothing is deleted; everything moves into
            cleared\, and manifest.jsonl - the log of everything ever sniped -
            is explicitly not part of the queue and must survive.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

SRC = os.path.dirname(os.path.abspath(__file__))
PORT, STATIC = 7395, 7396
BASE = "http://127.0.0.1:%d" % PORT
KEY = "routetest_000000000000000000000000"

passed = failed = 0


def check(label, cond, extra=""):
    global passed, failed
    if cond:
        passed += 1
        print("  [PASS] " + label)
    else:
        failed += 1
        print("  [FAIL] " + label + ("\n         " + str(extra) if extra else ""))


def post(path, body, key=KEY):
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "X-Sniper-Key": key},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode("utf-8") or "{}")
        except Exception:
            return e.code, {}


def get(path):
    req = urllib.request.Request(BASE + path, headers={"X-Sniper-Key": KEY})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def build(sandbox):
    """A copy of the project that cannot reach anything of yours: its own
    ports, its own key, and roots.json pointing back into itself."""
    for name in ("relay.py", "core.py", "place.py", "cache.py", "gamecheck.py",
                 "console.html", "sites.json", "config.json", "envs.json",
                 "starter.html", "sniper.user.js"):
        p = os.path.join(SRC, name)
        if os.path.exists(p):
            shutil.copy2(p, sandbox)

    src = open(os.path.join(sandbox, "relay.py"), encoding="utf-8").read()
    src = src.replace("PORT = 7355", "PORT = %d" % PORT, 1)
    src = src.replace("STATIC_PORT = 7356", "STATIC_PORT = %d" % STATIC, 1)
    open(os.path.join(sandbox, "relay.py"), "w",
         encoding="utf-8", newline="\n").write(src)

    open(os.path.join(sandbox, ".sniper_key"), "w").write(KEY)
    with open(os.path.join(sandbox, "roots.json"), "w") as fh:
        json.dump({"sniper": sandbox}, fh)


def main(sandbox):
    build(sandbox)
    proc = subprocess.Popen([sys.executable, "relay.py"], cwd=sandbox,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding="utf-8", errors="replace")
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(BASE + "/health", timeout=1).read()
                break
            except Exception:
                time.sleep(0.25)
        else:
            print("the test relay never came up on port %d" % PORT)
            return 1

        print("\npaste - text that walked in")
        status, r = post("/paste", {"text": "   \n  \n"})
        check("an empty paste is refused", status == 400, (status, r))

        body = ("<!-- >> sniper/envs/rougelike/index.html @replace -->\n"
                "<!DOCTYPE html>\n<html>\n<body>pasted</body>\n</html>\n")
        status, r = post("/paste", {"text": body})
        check("a paste is accepted", status == 200 and r.get("ok"), (status, r))
        check("the first-line directive is honoured",
              (r.get("target") or "").endswith("index.html"), r)
        check("so is its mode", r.get("mode") == "replace", r)
        pasted = r.get("id")

        q = get("/queue")
        check("it lands in pending", pasted in [d["id"] for d in q["pending"]],
              [d["id"] for d in q["pending"]])

        txt = os.path.join(sandbox, "drops", (pasted or "") + ".txt")
        check("the text file is on disk", os.path.exists(txt), txt)
        if os.path.exists(txt):
            on_disk = open(txt, encoding="utf-8").read()
            check("the body is verbatim, with the directive line removed",
                  on_disk.startswith("<!DOCTYPE html>")
                  and on_disk.endswith("</html>\n"), repr(on_disk[:40]))

        status, r = post("/paste", {"text": "let x = 1;\n"})
        check("an unaddressed paste still queues",
              status == 200 and r.get("ok") and not r.get("target"), (status, r))

        print("\nclear - tidying without destroying")
        status, r = post("/clear", {"stage": "envs"})
        check("refuses a directory that is not a stage", status == 400, (status, r))
        status, r = post("/clear", {"stage": ".." + os.sep + "Windows"})
        check("refuses a path pretending to be a stage", status == 400, (status, r))

        manifest = os.path.join(sandbox, "drops", "manifest.jsonl")
        open(manifest, "w").write('{"kept": true}\n')

        before = len(get("/queue")["pending"])
        check("there is something to clear", before >= 2, before)

        status, r = post("/clear", {"stage": "drops"})
        check("it reports what it moved",
              status == 200 and r.get("moved") == before * 2, (status, r, before))
        check("pending is empty afterwards", len(get("/queue")["pending"]) == 0)
        check("the manifest was not cleared with the queue",
              os.path.exists(manifest) and open(manifest).read() == '{"kept": true}\n')

        moved_to = os.path.join(sandbox, (r.get("to") or "").replace("\\", os.sep))
        check("the cleared files are where it said they went",
              os.path.isdir(moved_to), moved_to)
        if os.path.isdir(moved_to):
            names = os.listdir(moved_to)
            check("both halves of every drop moved", len(names) == before * 2, names)
            check("and the text is still readable",
                  any(n.endswith(".txt")
                      and "pasted" in open(os.path.join(moved_to, n),
                                           encoding="utf-8").read()
                      for n in names), names)

        status, r = post("/clear", {"stage": "drops"})
        check("clearing an empty stage is not an error",
              status == 200 and r.get("moved") == 0, (status, r))

        print("\nauth")
        status, r = post("/paste", {"text": "x"}, key="wrong")
        check("/paste needs the key", status == 401, (status, r))
        status, r = post("/clear", {"stage": "drops"}, key="wrong")
        check("/clear needs the key", status == 401, (status, r))

        print("-" * 60)
        print("  %d passed, %d failed\n" % (passed, failed))
        return 1 if failed else 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


if __name__ == "__main__":
    d = tempfile.mkdtemp(prefix="sniper-routetest-")
    try:
        sys.exit(main(d))
    finally:
        shutil.rmtree(d, ignore_errors=True)
