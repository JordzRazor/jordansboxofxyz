#!/usr/bin/env python3
"""
lint_names.py - find names used but never bound anywhere in a module.

Written after the same bug bit twice: relay.py referenced `load_roots` and then
`WORKING`, both of which only existed in place.py. Python does not complain
until the line actually runs - and when that line is inside an HTTP handler,
the failure surfaces to the browser as a bare "Failed to fetch" with no
traceback and no status code. This catches that class before it ships.

    python lint_names.py relay.py place.py selftest.py
"""

import ast
import builtins
import sys


def bound_names(tree):
    """Every name this module binds, in any scope. Deliberately permissive -
    we are hunting names that exist NOWHERE, not scope mistakes."""
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            out.add(node.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            out.add(node.name)
            args = getattr(node, "args", None)
            if args:
                for a in (list(args.args) + list(args.posonlyargs)
                          + list(args.kwonlyargs)):
                    out.add(a.arg)
                if args.vararg:
                    out.add(args.vararg.arg)
                if args.kwarg:
                    out.add(args.kwarg.arg)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names:
                out.add((a.asname or a.name).split(".")[0])
        elif isinstance(node, ast.ExceptHandler) and node.name:
            out.add(node.name)
        elif isinstance(node, ast.Lambda):
            for a in (list(node.args.args) + list(node.args.posonlyargs)
                      + list(node.args.kwonlyargs)):
                out.add(a.arg)
        elif isinstance(node, ast.Global) or isinstance(node, ast.Nonlocal):
            out.update(node.names)
    return out


def check(path):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    tree = ast.parse(src, path)
    known = bound_names(tree) | set(dir(builtins)) | {"__file__", "__name__", "self"}

    bad = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            if node.id not in known:
                bad.append((node.lineno, node.id))

    lines = src.split("\n")
    seen = set()
    for lineno, name in sorted(bad):
        if (lineno, name) in seen:
            continue
        seen.add((lineno, name))
        print(f"  {path}:{lineno}  undefined name {name!r}")
        print(f"      {lines[lineno - 1].strip()[:88]}")
    return len(seen)


def main(argv):
    targets = argv[1:] or ["relay.py", "place.py", "selftest.py"]
    total = 0
    for t in targets:
        total += check(t)
    print(f"\n  {total} undefined name(s)" if total
          else "\n  no undefined names")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
