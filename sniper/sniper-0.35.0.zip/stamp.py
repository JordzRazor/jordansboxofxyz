#!/usr/bin/env python3
"""stamp.py - record the userscript's bytes against the current version.

Run this after a DELIBERATE version bump. It writes VERSION.sha, which
make_dist checks: if sniper.user.js changes again without the version moving,
the build refuses. That is the failure this exists for - on 2026-09-12 two
different builds were both called 0.32.0, one live in the browser and one on
disk, and matching version numbers hid it completely.
"""
import hashlib
import io
import os

ROOT = os.path.dirname(os.path.abspath(__file__))

# The USERSCRIPT's version, not the project's. VERSION moves whenever anything
# ships; this file exists to pin the script's bytes to the number the browser
# installs, and those are different questions.
import re

with io.open(os.path.join(ROOT, "sniper.user.js"), encoding="utf-8") as fh:
    js = fh.read()
m = re.search(r"^//\s*@version\s+(\S+)", js, re.M)
if not m:
    raise SystemExit("sniper.user.js has no @version line")
ver = m.group(1)
sha = hashlib.sha256(js.encode("utf-8")).hexdigest()[:16]
with io.open(os.path.join(ROOT, "VERSION.sha"), "w", encoding="utf-8", newline="") as fh:
    fh.write("%s %s\n" % (ver, sha))

print("stamped %s %s" % (ver, sha))
