@echo off
setlocal
title sniper - setup
cd /d "%~dp0"

echo.
echo   ========================================
echo     sniper - drop this folder anywhere
echo   ========================================
echo.

rem  Python is the one genuine prerequisite: the relay is a Python program and
rem  there is no way around that. Check it here, by hand, so a missing install
rem  produces a sentence a person can act on rather than a stack trace.
set "PY="
where py >nul 2>&1 && set "PY=py"
if not defined PY where python >nul 2>&1 && set "PY=python"

if not defined PY (
  echo   Python is not installed, and sniper needs it.
  echo.
  echo   1. Get it from  https://www.python.org/downloads/
  echo   2. IMPORTANT: tick "Add python.exe to PATH" in the installer
  echo   3. Run this file again
  echo.
  echo   Opening the download page...
  start "" https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)

echo   Python found. Handing over to the installer...
echo.

rem  install.ps1 does the real work: starts the relay, waits for it to answer,
rem  and opens the one-click install URL with your key already in it. Called
rem  through cmd with -ExecutionPolicy Bypass because a .ps1 double-clicked
rem  from Explorer opens in Notepad, and the default policy blocks it anyway.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
echo   ----------------------------------------
echo    Done. If a browser tab opened asking to
echo    install a userscript, click Install.
echo.
echo    Then open a chat at chat.qwen.ai or
echo    chat.deepseek.com and reload the page.
echo   ----------------------------------------
echo.
pause
