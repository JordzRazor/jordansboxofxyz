#!/usr/bin/env python3
"""
gamecheck.py - static health check for a single-file HTML/JS game.

    python gamecheck.py envs/zombie/index.html

`analyse()` is the single source of truth about where things live and what looks
wrong. The human report here and the shared cache in cache.py are both built
from it, so the Placer and the Gardener can never disagree about the location of
a symbol - they are reading the same derivation, not two lookalike ones.

Regex-based, deliberately. There is no JS parser here, so every finding is a
LEAD to verify, not a verdict. It errs toward reporting.
"""

import os
import re
import sys

KNOWN = {
    "if", "for", "while", "switch", "catch", "return", "function", "typeof",
    "new", "delete", "void", "in", "of", "do", "else", "try", "throw", "case",
    "console", "window", "document", "Math", "JSON", "Object", "Array", "String",
    "Number", "Boolean", "Date", "Promise", "Set", "Map", "WeakMap", "WeakSet",
    "Error", "parseInt", "parseFloat", "isNaN", "isFinite", "encodeURIComponent",
    "decodeURIComponent", "setTimeout", "setInterval", "clearTimeout",
    "clearInterval", "requestAnimationFrame", "cancelAnimationFrame",
    "performance", "localStorage", "sessionStorage", "navigator", "location",
    "alert", "confirm", "prompt", "fetch", "THREE", "Audio", "AudioContext",
    "Float32Array", "Uint8Array", "Uint16Array", "Int32Array", "MessageChannel",
    "CustomEvent", "Event", "InputEvent", "PointerEvent", "KeyboardEvent",
    "MouseEvent", "ResizeObserver", "MutationObserver", "structuredClone",
    "queueMicrotask", "getComputedStyle", "matchMedia", "Symbol", "BigInt",
    "Intl", "RegExp", "Function", "Proxy", "Reflect", "globalThis",
    "addEventListener", "removeEventListener", "dispatchEvent", "open",
    "close", "focus", "blur", "scrollTo", "getSelection", "postMessage",
    "btoa", "atob", "isSecureContext", "reportError",
}

# Column 0 only. An indented `const d = ...` is a local inside some function,
# and treating those as top-level makes every short name look duplicated.
DEF_PATTERNS = [
    ("function", re.compile(r"^(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)")),
    ("const",    re.compile(r"^const\s+([A-Za-z_$][\w$]*)\s*=")),
    ("let",      re.compile(r"^let\s+([A-Za-z_$][\w$]*)\s*=")),
    ("var",      re.compile(r"^var\s+([A-Za-z_$][\w$]*)\s*=")),
    ("class",    re.compile(r"^class\s+([A-Za-z_$][\w$]*)")),
]

# Lookbehind excludes `.foo(` (a method - somebody else's business) and keeps
# `$(` working, which a plain \b would not match.
CALL = re.compile(r"(?<![\w$.])([A-Za-z_$][\w$]*)\s*\(")
STRIP_STR = re.compile(r"""(?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`)""")
STRIP_COMMENT = re.compile(r"//[^\n]*|/\*.*?\*/", re.S)


def scripts_from(src, path):
    if not path.lower().endswith((".html", ".htm")):
        return [(src, 0)]
    out = []
    for m in re.finditer(r"<script\b[^>]*>(.*?)</script>", src, re.S | re.I):
        if "importmap" in (m.group(0)[:120] or "").lower():
            continue
        out.append((m.group(1), src[:m.start(1)].count("\n")))
    return out


def scrub(code):
    """Blank strings and comments so they don't produce phantom symbols."""
    code = STRIP_COMMENT.sub(lambda m: " " * len(m.group(0)), code)
    return STRIP_STR.sub(lambda m: '"' + " " * (len(m.group(0)) - 2) + '"', code)


def analyse(path):
    """Everything both agents need to know, derived once."""
    with open(path, encoding="utf-8", errors="replace") as fh:
        src = fh.read()
    blocks = scripts_from(src, path)
    all_code = scrub("\n".join(c for c, _ in blocks))

    symbols = {}
    for code, offset in blocks:
        for i, line in enumerate(scrub(code).split("\n"), 1):
            for kind, rx in DEF_PATTERNS:
                m = rx.match(line)
                if m:
                    symbols.setdefault(m.group(1), []).append(
                        {"kind": kind, "line": i + offset})
                    break

    called = {}
    for code, offset in blocks:
        for i, line in enumerate(scrub(code).split("\n"), 1):
            for m in CALL.finditer(line):
                called.setdefault(m.group(1), []).append(i + offset)

    bound = set(symbols)
    for rx in (re.compile(r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)"),
               re.compile(r"\bfunction\s+([A-Za-z_$][\w$]*)"),
               re.compile(r"\bclass\s+([A-Za-z_$][\w$]*)")):
        bound.update(rx.findall(all_code))

    findings = []
    for name, where in sorted(symbols.items()):
        if len(where) > 1:
            findings.append({
                "id": f"dup:{name}", "kind": "duplicate-definition",
                "symbol": name, "line": where[0]["line"],
                "detail": "defined at " + ", ".join(
                    f"{w['kind']} L{w['line']}" for w in where),
                "why": "a patch applied twice, or an old definition never removed",
            })

    for name, lines in sorted(called.items()):
        if name in bound or name in KNOWN or name[0].isupper():
            continue
        findings.append({
            "id": f"missing:{name}", "kind": "called-but-undefined",
            "symbol": name, "line": lines[0],
            "detail": "called at L" + ", L".join(str(l) for l in lines[:6]),
            "why": "a patch may have renamed or removed it",
        })

    for name, where in sorted(symbols.items()):
        hits = len(re.findall(r"(?<![\w$.])" + re.escape(name) + r"(?![\w$])", all_code))
        if hits <= len(where):
            findings.append({
                "id": f"unused:{name}", "kind": "defined-never-used",
                "symbol": name, "line": where[0]["line"],
                "detail": f"defined at L{where[0]['line']}, referenced nowhere else",
                "why": "usually a feature a later patch quietly unplugged - "
                       "prefer re-wiring it to deleting it",
            })

    static_html = re.sub(r"<script\b[^>]*>.*?</script>", "", src, flags=re.S | re.I)
    ids = re.findall(r'\bid\s*=\s*"([^"]+)"', static_html)
    for i in sorted({i for i in ids if ids.count(i) > 1}):
        findings.append({
            "id": f"dupid:{i}", "kind": "duplicate-html-id", "symbol": i,
            "line": 0, "detail": f'id="{i}" appears {ids.count(i)} times',
            "why": "getElementById returns only the first",
        })

    balance = {}
    for name, op, cl in (("paren", "(", ")"), ("brace", "{", "}"),
                         ("bracket", "[", "]")):
        d = src.count(op) - src.count(cl)
        balance[name] = d
        if d:
            findings.append({
                "id": f"balance:{name}", "kind": "unbalanced",
                "symbol": name, "line": 0, "detail": f"{d:+d}",
                "why": "something was cut off or pasted twice",
            })

    return {
        "path": path.replace("\\", "/"),
        "lines": src.count("\n") + 1,
        "script_blocks": len(blocks),
        "symbols": symbols,
        "balance": balance,
        "findings": findings,
    }


def report(a):
    """The human view. Ends with the line the relay parses for a count."""
    out = []
    w = out.append
    w("=" * 64)
    w(f"  {os.path.basename(a['path'])} - {a['lines']} lines, "
      f"{a['script_blocks']} script block(s), {len(a['symbols'])} top-level definitions")
    w("=" * 64)

    groups = [
        ("duplicate-definition", "DEFINED MORE THAN ONCE"),
        ("called-but-undefined", "CALLED BUT NEVER DEFINED"),
        ("defined-never-used", "DEFINED BUT APPARENTLY NEVER REFERENCED"),
        ("duplicate-html-id", "DUPLICATE HTML ids"),
        ("unbalanced", "DELIMITER IMBALANCE"),
    ]
    for n, (kind, title) in enumerate(groups, 1):
        rows = [f for f in a["findings"] if f["kind"] == kind]
        w(f"\n[{n}] {title}")
        if not rows:
            w("    none")
        for f in rows[:25]:
            w(f"    {f['symbol']:<24} {f['detail']}")

    w("\n[6] BALANCE")
    for k, v in a["balance"].items():
        w(f"    {k:<8} {v:+d}")

    w("\n" + "=" * 64)
    w(f"  {len(a['findings'])} lead(s) to look at. Each is a LEAD, not a verdict -")
    w("  this is regex, not a parser. Verify before changing anything.")
    w("=" * 64)
    return "\n".join(out)


def default_target():
    """The current environment's entry file. Read, never hardcoded - cache.py
    imports this too, so the whole toolchain follows one setting."""
    here = os.path.dirname(os.path.abspath(__file__))
    name = ""
    try:
        import json
        with open(os.path.join(here, "config.json"), encoding="utf-8") as fh:
            name = (json.load(fh).get("current_env") or "").strip()
    except Exception:
        pass
    if not name:
        try:
            import json
            with open(os.path.join(here, "envs.json"), encoding="utf-8") as fh:
                names = sorted(json.load(fh))
            name = names[0] if names else "demo"
        except Exception:
            name = "demo"
    return os.path.join("envs", name, "index.html")


def main(argv):
    path = argv[1] if len(argv) > 1 else default_target()
    if not os.path.exists(path):
        print(f"no such file: {path}", file=sys.stderr)
        return 2
    print(report(analyse(path)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
