# sniper

Ship text out of a designated web page into a local staging area, so code
written in a browser chat lands in the right file on disk without a copy-paste
round trip.

```
chat.deepseek.com / chat.qwen.ai   (your tab, already logged in)
   |
   |  userscript: "→ Claude" on every code block   (Alt+S = selection)
   v
GM_xmlhttpRequest --POST--> 127.0.0.1:7355/drop   (+ X-Sniper-Key)
   |
   +--> code       --> drops\          staged, waiting for you to apply it
   +--> whole page --> envs\<name>\    deployed live, and written to the ledger
   +--> prose      --> context\        read for intent, never placed as a file
   |
   v
snipes.jsonl   every snipe, and what became of it
```

## Two landing places, and only two

Context is allowed to go straight in: an explanation lands in `context\` and is
read for intent, never placed as a file.

**Code is different. Code lands in pending, or it lands in completed. There is
no third door.** Every byte that reaches a target is recorded in `applied.jsonl`
with a sha before and after and a backup path, so the console can always account
for what is on disk.

This is a rule with a scar behind it. For two days a whole-page capture was
written straight into an environment with no drop and no ledger line, and the
console sat showing an empty queue beside a 9 KB file nobody could explain. The
fast path is still fast; it just writes itself down now.

## Why it works this way

No credential is ever handled. The relay does not authenticate to DeepSeek or
Qwen, holds no session token, and never touches their API — the browser you are
already logged into does the reading, and forwards only the text you point at.
That sidesteps the whole auth problem: proof-of-work headers, token rotation and
ToS on automated access are simply not in the path.

`GM_xmlhttpRequest` (not `fetch`) is required: it runs in the extension context,
so the page's Content-Security-Policy cannot block the hop to localhost.

## Safety properties

- **Loopback only.** Binds `127.0.0.1`. The Host header is checked, so a hostile
  page cannot reach it by rebinding DNS to 127.0.0.1.
- **Shared secret.** `X-Sniper-Key` must match `.sniper_key`, compared with
  `hmac.compare_digest`. No key, no drop.
- **The relay writes to two places, both accounted for.** `drops\` for staged
  code, and `envs\<name>\index.html` for a whole page it deploys — and a deploy
  writes a backup, an `applied\` record and an `applied.jsonl` line while it
  does. It never writes into your projects; that is `place.py`, confined to
  `roots.json`.
- **A name, never a command.** Launching an environment or revealing a folder
  takes a NAME that is looked up locally. A `cmd` smuggled in beside a valid
  name is ignored — verified, along with unknown names (404) and no key (401).
- **Drops are data, not instructions.** The text is a remote model's output. It
  is read as content to place, never as direction to follow.
- **The published userscript carries no key.** The working copy has the secret
  inline; the site build replaces it with a placeholder and refuses to write if
  the real key survives anywhere in the output.

## Setup

1. **Start the relay.** Double-click **Sniper Relay** on the desktop, or:

   ```
   cd %USERPROFILE%\sniper
   .\tray.ps1        background, tray icon, auto-restarts on a code change
   .\run.ps1         a visible window instead, if you want to watch the log
   ```

2. **Install the userscript from the relay, not from a file.**

   ```
   .\install.ps1     starts the relay and opens the install URL
   ```

   That URL is `http://127.0.0.1:7355/sniper.user.js?key=<your key>`, and it
   matters which way you install. The relay injects `@updateURL` and
   `@downloadURL` pointing back at itself and bakes your key in, so updates are
   one click forever after. A copy dragged onto Tampermonkey has neither — it
   works, and then silently never updates again.

3. **Chrome only:** `chrome://extensions` → Tampermonkey → Details → enable
   **Allow User Scripts**. Without it, MV3 Chrome runs nothing and says nothing.

4. **Reload the chat tab.** The toast names the version it is running.

No elevation is needed at any point, autostart included.

Check the relay any time: `curl http://127.0.0.1:7355/health`

## Running it in the background

`tray.ps1` keeps the relay in the notification area with no console window.

- **The log moves, it does not disappear.** That window used to *be* the log, so
  hidden means the output goes to `runs\relay-<stamp>.log` and the tray menu
  opens it. Hiding the window is fine; losing the evidence never is.
- **It never serves stale code.** `relay.py` is the only file that needs a
  restart to take effect — `console.html`, `sites.json` and `roots.json` are
  re-read on every request — so the tray watches its bytes and restarts the
  child the moment they change.
- **A crash announces itself** with a balloon and the log path. A silent
  background process that died an hour ago is worse than no background process.

Menu: open console, show log, open folder, restart, stop and quit. Double-click
opens the console.

## The console is the panel

**http://127.0.0.1:7355/console** — also the first entry in the `⧉` menu on the
chat page.

Routing a drop is a judgement call, and judgement calls belong on a page we
control, not in a userscript wedged into someone else's DOM. It polls every 3s,
so a fresh snipe appears while you are looking at it.

It is a **front end over `place.py`, not a second implementation** — every
action shells out to the same CLI, so containment, backups and `applied.jsonl`
logging are identical whichever way you drive it. Verified: a
`..\..\Windows\System32\...` target typed into the console is refused by the
same check that refuses it on the command line.

### The net — where did my code go

`GET /trace`, and the RECENT SNIPES strip, answer that without opening four
folders. Every snipe ends in exactly one of:

| outcome | meaning |
|---|---|
| `queued` | staged in `drops\`, waiting for you |
| `deployed` | written into an environment, and ledgered |
| `identical` | already deployed, byte for byte — nothing to do |
| `duplicate` | the same text is already waiting in the queue |
| `context` | prose, filed for intent |
| `refused` | a guard turned it away; the evidence is kept |

`identical` exists because silence used to be indistinguishable from success.

### Phase — is what I am looking at real

`GET /phase` reports the version of every moving part, and every environment
file the ledger cannot account for. The console turns red and says so. Three
ways to be out of phase: the userscript disagrees with itself, the tab is
running an older script than the relay serves, or **a file holds bytes the queue
never put there**. That last one is the serious one.

The strip has a close button, and dismissing is scoped to the reasons you
dismissed — anything new brings it straight back.

### Clearing

Each section header has a **clear** control. It moves that stage into `cleared\`
rather than deleting, and `manifest.jsonl` — the log of everything ever sniped —
is explicitly not part of the queue and survives.

## Reading a code block that is not text

Qwen does not render code as markup. It mounts **a Monaco editor per block** —
the same editor VS Code uses — and Monaco is a virtual list: `.view-lines` holds
only the lines the viewport can show, and the line divs are recycled.

That one fact caused every Qwen symptom the project had been chasing separately:
shuffled reads with `}` before its `{`, a gutter counting 27,28,29,24,25,26,
NBSP whitespace, and an "opens `<html>`, never closes it" refusal on a document
that only ever had 29 lines mounted. **No amount of reading the screen recovers
a line that was never mounted.** It does not exist.

So the capture asks the editor instead, best route first:

1. **The model** — `monaco.editor`, when the page leaves it on `window`. Exact
   and instant. Qwen does not, so in practice this is route two.
2. **Mount and harvest** — give the viewport the height of the whole document so
   Monaco mounts it, then pair each rendered line with its gutter number.
3. **Scroll and harvest** — wheel through the block, merging what mounts.

Routes 2 and 3 join text to line number by the `top` Monaco puts on both, which
is an exact key rather than a guess. Because every line arrives numbered, "this
is the whole document" becomes a count you can prove.

**The gutter is the truth; the spacer is a hint.** `.lines-content` is sized to
the scroll height, and on Qwen that came back as **16777200px** — 2²⁴ − 16, the
browser's maximum element height, not a length Monaco chose. Divided by a 20px
line, that is 838,860 imaginary lines: a complete 243-line capture ending in
`</html>` was refused for "missing 244-838860", while the assembler built 847 KB
that was 99.98% blank. An implausible spacer is now discarded, and the highest
line number actually seen is the length.

If a site still will not give its text up, the console's **⌸ paste** box takes
the block whole and stages it like anything sniped.

## The guards, and what they do not run on

- **Settle** — read, wait, read again, send when the text stops moving. Applies
  to everything.
- **Structural check** — a line repeated verbatim, a line followed by a
  truncated copy of itself, or a positive paren/bracket imbalance. **Code only.**
  Balanced delimiters are a property of code, not English; running this on prose
  once rejected a 363-line explanation for one unclosed parenthesis inside a
  table. The page fetches `GET /routing` at startup so it knows which kinds are
  code.
- **Repair, do not refuse.** A bad render is mechanical — a complete line
  followed by an identical or truncated copy — so the debris is removed and the
  result re-verified before it is trusted. The drop is flagged `repaired`.
- **Refusals are kept.** `refused\` holds the verbatim capture, the reason, what
  a repair would have removed, what would still be wrong afterwards, and the
  counts behind "it is cut off". Before this, "it just refused" was
  undebuggable — the one path that threw its evidence away.

## Addressing a drop

The first line of a block may carry its own coordinates. It is stripped from the
`.txt`, so the sidecar is ready to place verbatim:

```
// >> mcmod\pack\data\foo.mcfunction @replace
<the actual content>
```

- Comment leader may be `//`, `#`, `--`, `;`, `%`, `<!--`, `/*`, or absent.
- Modes: `@replace` (default), `@new`, `@append`, `@patch`, `@note`.
- Anything after the mode is kept as a free-text `note`.
- No directive is fine — the drop is staged unaddressed, for a human to route.

## Environments

The `⧉` pill on the chat page (`Alt+E`) **reads the current target** — it says
`⧉ rougelike`, not `⧉ load environment` — and its menu starts with **+ new
environment**, which names it, creates it, binds this chat to it and opens it in
one gesture. Picking an existing one binds this chat to it first and opens it
second: choosing is declaring.

```json
{
  "zombie": { "type": "web", "label": "Zombie game (three.js)" },
  "sim":    { "type": "app", "label": "Braid sim",
              "cmd": ["python", "sim.py"], "cwd": "C:/Users/you/some-project" }
}
```

- **`web`** — served from `envs\<name>\` on **127.0.0.1:7356** (same process,
  second port).
- **`app`** — the relay launches `cmd` locally, for anything not web-native.

`web` exists because **three.js needs a real HTTP origin** — ES module imports
and texture loads are blocked on `file://`. The static server sets
`Content-Type: text/javascript` for `.js`/`.mjs` (without it `<script
type="module">` is refused outright) and `Cache-Control: no-store`, so the loop
is snipe → reload → see it.

**Whole pages deploy immediately.** A complete HTML document with no explicit
`>>` target goes straight into the bound environment and is live on reload — and
it writes a backup, an `applied\` record and an `applied.jsonl` line while it
does. Set `autoenv.enabled: false` in `config.json` and whole pages queue like
everything else.

**The declaration wins.** A chat that has declared an environment keeps it;
auto-naming from `<title>` is only for a conversation that has never declared
one, which is the only case where guessing is unavoidable.

## Buttons on the chat page

| control | does |
|---|---|
| `→ Claude` | one code block |
| `→ msg` | the whole message as prose, to `context\` |
| `→ all` | **every code block in that message, in order** |
| `Alt+S` | the current selection |
| `Alt+A` | `→ all` on the last message |
| `Alt+C` | `⇩ codebase` — send the actual source |
| `Alt+R` | house rules for a new chat |
| `Alt+W` | `⇧ what landed` — what applied, what did not, and why |
| `Alt+D` | force a DOM census |
| `Alt+E` / `⧉` | environments + review console |

`→ all` does **not** macro-click the individual buttons. The script already
holds the elements and the same posting authority, so it drives the send loop
directly — no synthetic events, no timing guesswork. Blocks go in document
order, which is the order they were written and so the order to apply them.

**A message that contains a code block does not drag that code into the prose.**
The editor is excluded from a message read and a marker is left in its place;
the code travels by the queue, the only path that can read it exactly.

**`⇧ what landed` closes the loop.** Without it the chat sees silence when a
patch is deliberately rejected, and "corrects" by sending bigger blocks. It
reports the placer's exact reason for each.

## The shared map — why the snipe stops missing

Targeting was hard for one reason: the model was writing blind. It had no idea
what was already in the file, so it could not say where a change belonged.

**`⇩ codebase`** (`Alt+C`) sends `GET /context?form=full` — the **actual
source**, not a summary — plus the `>>` addressing syntax. It goes to the
clipboard *and* the composer, since a controlled React input can refuse a
programmatic value at that size.

| form | size here | what it is |
|---|---|---|
| `rules` | 1 KB | house rules for a new chat (`Alt+R`) |
| `map` | 6 KB | file list + symbol outline with line numbers |
| `full` | 74 KB | the whole source in a fence, plus the protocol |

The fence is computed to be longer than any backtick run in the file, so a
template literal in the code cannot terminate the block early — verified to
round-trip byte-for-byte.

Rule one of the house rules is the fencing rule, because it is the one that
actually breaks things: always a `javascript` or `html` fence, never `text` or a
bare one. Un-highlighted blocks are what renderers mangle.

## The gardener

Second tab in the console. The drops tab places code the chat sent you; the
gardener tab tends code already on disk.

```
python gamecheck.py envs/zombie/index.html
```

That check runs first, and the console shows its report before you call anyone:
definitions applied twice, calls to functions a patch renamed away, definitions
nothing references, duplicate static ids, delimiter balance. Regex, not a parser
— **every line is a lead, not a verdict**.

The tab carries a badge only when there is something to do. **Ideally it stays
empty**: a clean check means the placer is doing its job.

Its remit is small, dull, load-bearing repairs. It does **not** rename,
refactor, restructure or change balance; if a change is a matter of taste it is
not the gardener's to make. It backs up before editing and re-runs the check
afterwards, to prove the findings went down rather than sideways.

## The Code Placer

A staged drop is not applied. Something has to place it.

```
.\placer.ps1                 open a Code Placer terminal (Sonnet 5)
.\placer.ps1 -Model opus     heavier sniper for a gnarly queue
.\placer.ps1 -Name mcmod     label it; run as many terminals as you like
```

Each terminal reads `CLAUDE.md` and drains the queue with `place.py`. `claim` is
atomic, so parallel placers never fight over the same drop.

```
python place.py list                    what is pending
python place.py wait --timeout 600      park until a drop lands — costs no tokens
python place.py claim <id>              take it
python place.py show  <id>              metadata + full text
python place.py apply <id>              write it, with an automatic backup
python place.py reject <id> "reason"    park it unapplied
python place.py auto                    drain every unambiguous drop, NO model
python place.py roots                   show the root map
```

**`auto` is the cheap path.** A `@replace` with an explicit target is a verbatim
byte-for-byte write — a model adds nothing to that but cost and a chance of
transcription error. Open a placer terminal for `@patch`, unaddressed drops, and
anything needing judgement.

A drop moves `drops\` → `working\` → `applied\` | `rejected\`. Every overwrite is
backed up first and logged with sha256 before/after, so any placement can be
undone.

**Confinement:** `place.py` only writes inside the roots in `roots.json`, and
refuses any target that resolves outside them. Edit `roots.json` to add a
project.

## Designating another site

Per-site DOM adapters live in **`sites.json`**, which the userscript fetches from
the relay at startup. Tuning a selector is an edit and a tab reload, not a
re-install:

```json
"chat.qwen.ai": {
  "code":     ["pre", "[class*=\"code-block\"]"],
  "messages": [".chat-response-message"],
  "exclude":  [".monaco-editor"],
  "ui":       { "codeTop": "6px", "codeRight": "84px" }
}
```

Only the `@match` lines still live in the script header, because a browser needs
those at install time. Open the site and press `Alt+D`: the census reports which
selectors hit, the most common classes on text-bearing nodes, and — if the page
uses Monaco — the editor's own numbers.

## Versions

Two numbers, and they are deliberately not the same.

| where | what it is |
|---|---|
| `VERSION` | the project: relay, console, userscript, all of it |
| `@version` + `const VERSION` | the **userscript's** own version |

Tampermonkey compares `@version` and nothing else, so it must move when — and
only when — the script's bytes move. A bump with no change makes "update
available" mean nothing; a change with no bump leaves two different builds
wearing one number, which is exactly how a browser once ran code the disk did
not have.

`VERSION.sha` pins the script's bytes to its own version. `make_dist.py` refuses
to build if the script changed since it was stamped, or if `@version` and
`const VERSION` disagree. After a deliberate bump, run `python stamp.py`.

A relay-only fix does not touch the userscript, and does not ask you to
reinstall anything.

## Layout

```
relay.py          the server: capture, routing, guards, ledger, console, /phase
tray.ps1          background supervisor: tray icon, log to runs\, auto-restart
run.ps1           the same relay with a visible window
sniper.user.js    the userscript (the key is inline — never publish this copy)
sites.json        per-site DOM adapters, served at /sites
console.html      the panel
place.py          the queue CLI: claim, apply, reject, auto
core.py           the corruption judgement, shared with the cloud half
gamecheck.py      the gardener's instrument
stamp.py          pin the userscript's bytes to its version
selftest.py       relay end to end        flowtest.py     the whole journey
routetest.py      /paste and /clear       test_monaco.js  the Monaco readers
```
