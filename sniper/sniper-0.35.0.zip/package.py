#!/usr/bin/env python3
"""
package.py - assemble the deployable cloud app.

    python package.py            build dist/cloud/
    python package.py --zip      build and zip it for Azure's zip-deploy

core.py lives at the project root because BOTH halves import it. Copying it in
at build time is what keeps that true: the cloud cannot drift from the local
relay, because it is literally the same file.
"""

import argparse
import ast
import os
import shutil
import sys
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
CLOUD = os.path.join(ROOT, "cloud")
DIST = os.path.join(ROOT, "dist", "cloud")

# (source, name in the package)
FILES = [
    (os.path.join(CLOUD, "app.py"), "app.py"),
    (os.path.join(CLOUD, "console.html"), "console.html"),
    (os.path.join(ROOT, "core.py"), "core.py"),          # shared, not duplicated
    (os.path.join(CLOUD, "requirements.txt"), "requirements.txt"),
    (os.path.join(CLOUD, "DEPLOY.md"), "DEPLOY.md"),
    (os.path.join(ROOT, "config.json"), "config.json"),  # routing table
]


def build(make_zip=False):
    # Remove only the files this script owns. dist/cloud also holds data/ when
    # you run the app locally to test it, and wiping that takes your test queue
    # with it - which it did, once.
    os.makedirs(DIST, exist_ok=True)
    for _src, name in FILES:
        stale = os.path.join(DIST, name)
        if os.path.exists(stale):
            try:
                os.remove(stale)
            except OSError as exc:
                print("  could not replace %s: %s" % (name, exc), file=sys.stderr)
                print("  (is the app still running from dist/cloud?)", file=sys.stderr)
                return 1

    missing = [src for src, _ in FILES if not os.path.exists(src)]
    if missing:
        for m in missing:
            print("  MISSING %s" % m, file=sys.stderr)
        return 1

    total = 0
    for src, name in FILES:
        dst = os.path.join(DIST, name)
        shutil.copy2(src, dst)
        size = os.path.getsize(dst)
        total += size
        print("  %-20s %8s bytes" % (name, format(size, ",")))

    # Fail loudly rather than shipping something that cannot start.
    with open(os.path.join(DIST, "app.py"), encoding="utf-8") as fh:
        app_src = fh.read()
    if "def app(" not in app_src:
        print("  app.py has no `app` callable - Azure will not find it",
              file=sys.stderr)
        return 1
    for name in ("app.py", "core.py"):
        try:
            ast.parse(open(os.path.join(DIST, name), encoding="utf-8").read())
        except SyntaxError as exc:
            print("  %s does not parse: %s" % (name, exc), file=sys.stderr)
            return 1

    print("\n  dist/cloud ready - %s bytes" % format(total, ","))

    zpath = os.path.join(ROOT, "dist", "sniper-cloud.zip")
    if not make_zip and os.path.exists(zpath):
        # A zip left over from a previous build is worse than none: it looks
        # deployable and is not. Remove it rather than let it mislead.
        os.remove(zpath)
        print("  removed the previous zip (it no longer matches) - "
              "rerun with --zip when you want one")

    if make_zip:
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            for _src, name in FILES:
                z.write(os.path.join(DIST, name), name)
        print("  %s  (%s bytes)" % (zpath, format(os.path.getsize(zpath), ",")))
        print("\n  deploy it with:")
        print("    az webapp deploy --resource-group <rg> --name <app> \\")
        print("        --src-path dist/sniper-cloud.zip --type zip")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", action="store_true")
    sys.exit(build(ap.parse_args().zip))
